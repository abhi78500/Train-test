import React, { useState, useEffect } from 'react';
import { Restaurant, MenuItem } from '../types';
import { XMarkIcon } from './IconComponents';

interface MenuManagerModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (restaurant: Restaurant) => void;
    restaurant: Restaurant | null;
}

const BLANK_MENU_ITEM: Omit<MenuItem, 'id'> = {
    name: '',
    description: '',
    price: 0,
    veg: true,
    image: '',
};

const MenuItemForm: React.FC<{
    item: MenuItem | Omit<MenuItem, 'id'>;
    onSave: (item: MenuItem | Omit<MenuItem, 'id'>) => void;
    onCancel: () => void;
}> = ({ item, onSave, onCancel }) => {
    const [formData, setFormData] = useState(item);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value, type } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: type === 'number' ? parseFloat(value) || 0 : value,
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(formData);
    };

    return (
        <form onSubmit={handleSubmit} className="bg-slate-100 p-4 rounded-lg my-4 space-y-4 border border-slate-200">
            <h3 className="text-lg font-bold text-slate-800">{'id' in item ? 'Edit Menu Item' : 'Add New Menu Item'}</h3>
            <div>
                <label htmlFor="name" className="block text-sm font-medium text-slate-700">Name</label>
                <input type="text" name="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm" />
            </div>
            <div>
                <label htmlFor="description" className="block text-sm font-medium text-slate-700">Description</label>
                <textarea name="description" value={formData.description} onChange={handleChange} required rows={2} className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm" />
            </div>
            <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label htmlFor="price" className="block text-sm font-medium text-slate-700">Price (₹)</label>
                    <input type="number" name="price" value={formData.price} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm" />
                </div>
                <div>
                     <label htmlFor="image" className="block text-sm font-medium text-slate-700">Image URL</label>
                    <input type="text" name="image" value={formData.image} onChange={handleChange} placeholder="Optional" className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm" />
                </div>
            </div>
            <div className="flex justify-end gap-2">
                <button type="button" onClick={onCancel} className="px-4 py-2 rounded-md font-semibold text-slate-700 bg-slate-200 hover:bg-slate-300">Cancel</button>
                <button type="submit" className="px-4 py-2 rounded-md font-semibold text-white bg-primary-600 hover:bg-primary-700">Save Item</button>
            </div>
        </form>
    );
};

const MenuManagerModal: React.FC<MenuManagerModalProps> = ({ isOpen, onClose, onSave, restaurant }) => {
    const [menu, setMenu] = useState<MenuItem[]>([]);
    const [editingItem, setEditingItem] = useState<MenuItem | Omit<MenuItem, 'id'> | null>(null);

    useEffect(() => {
        if (isOpen && restaurant) {
            setMenu([...restaurant.menu].sort((a,b) => a.id - b.id));
        } else {
            setMenu([]);
        }
        setEditingItem(null);
    }, [isOpen, restaurant]);

    const handleAddNew = () => {
        setEditingItem(BLANK_MENU_ITEM);
    };

    const handleEdit = (item: MenuItem) => {
        setEditingItem(item);
    };

    const handleDelete = (itemId: number) => {
        if (window.confirm('Are you sure you want to delete this item?')) {
            setMenu(prev => prev.filter(item => item.id !== itemId));
        }
    };

    const handleSaveItem = (itemData: MenuItem | Omit<MenuItem, 'id'>) => {
        if ('id' in itemData) { // Editing existing
            setMenu(prev => prev.map(item => item.id === itemData.id ? itemData : item));
        } else { // Adding new
            const newId = menu.length > 0 ? Math.max(...menu.map(i => i.id)) + 1 : 101;
            const newItem: MenuItem = { ...itemData, id: newId };
            setMenu(prev => [...prev, newItem]);
        }
        setEditingItem(null);
    };

    const handleSaveChanges = () => {
        if (!restaurant) return;
        onSave({ ...restaurant, menu });
    };

    if (!isOpen || !restaurant) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm z-50 flex items-start justify-center p-4 overflow-y-auto" onClick={onClose}>
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl transform transition-all my-8" onClick={(e) => e.stopPropagation()}>
                <div className="p-6">
                    <div className="flex justify-between items-center mb-4">
                        <div>
                           <h2 className="text-2xl font-bold text-slate-800">Manage Menu</h2>
                           <p className="text-slate-600">{restaurant.name}</p>
                        </div>
                        <button type="button" onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100">
                            <XMarkIcon className="w-6 h-6" />
                        </button>
                    </div>

                    {editingItem ? (
                        <MenuItemForm item={editingItem} onSave={handleSaveItem} onCancel={() => setEditingItem(null)} />
                    ) : (
                        <div className="my-4">
                            <button onClick={handleAddNew} className="w-full bg-primary-100 text-primary-700 font-bold py-2 px-4 rounded-md hover:bg-primary-200 border border-dashed border-primary-400 transition-colors">
                                + Add New Menu Item
                            </button>
                        </div>
                    )}
                    
                    <div className="space-y-2 max-h-[50vh] overflow-y-auto pr-2">
                        {menu.map(item => (
                            <div key={item.id} className="bg-white p-3 rounded-lg border flex items-center gap-4">
                               <img src={item.image || `https://picsum.photos/seed/${item.id}/200`} alt={item.name} className="w-16 h-16 object-cover rounded-md" />
                                <div className="flex-grow">
                                    <h4 className="font-bold text-slate-800">{item.name}</h4>
                                    <p className="text-sm text-slate-500">{item.description}</p>
                                    <p className="text-sm font-semibold text-primary-700 mt-1">₹{item.price}</p>
                                </div>
                                <div className="flex flex-col gap-2">
                                    <button onClick={() => handleEdit(item)} className="text-xs font-medium text-blue-600 hover:text-blue-800">Edit</button>
                                    <button onClick={() => handleDelete(item.id)} className="text-xs font-medium text-red-600 hover:text-red-800">Delete</button>
                                </div>
                            </div>
                        ))}
                         {menu.length === 0 && !editingItem && <p className="text-slate-500 text-center py-8">This restaurant has no menu items yet.</p>}
                    </div>

                </div>
                <div className="bg-slate-50 p-4 flex justify-end gap-4 rounded-b-2xl border-t">
                    <button type="button" onClick={onClose} className="px-6 py-2 rounded-md font-semibold text-slate-700 bg-slate-200 hover:bg-slate-300">Cancel</button>
                    <button type="button" onClick={handleSaveChanges} className="px-6 py-2 rounded-md font-semibold text-white bg-primary-600 hover:bg-primary-700">Save All Changes</button>
                </div>
            </div>
        </div>
    );
};

export default MenuManagerModal;
