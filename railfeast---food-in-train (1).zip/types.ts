

export interface MenuItem {
    id: number;
    name: string;
    description: string;
    price: number;
    veg: boolean;
    image: string;
}

export interface Restaurant {
    id: number;
    name: string;
    station: string;
    stationCode: string;
    deliveryTime: string;
    rating: number;
    cuisine: string;
    image: string;
    menu: MenuItem[];
}

export interface CartItem {
    item: MenuItem;
    quantity: number;
}

export type Page = 'home' | 'stations' | 'restaurants' | 'menu' | 'checkout' | 'confirmation' | 'track_order' | 'order_history' | 'order_details' | 'about_us' | 'privacy_policy' | 'terms_conditions' | 'partner_with_us' | 'vendor_dashboard' | 'agent_dashboard' | 'admin_dashboard';

export type OrderStatus = 'Pending' | 'Accepted' | 'Preparing' | 'Out for Delivery' | 'Delivered' | 'Cancelled';

export type PaymentMethod = 'COD' | 'Online';
export type PaymentStatus = 'Paid' | 'Unpaid';

export interface OrderDetails {
    id: string;
    date: string;
    restaurantName: string;
    restaurantId: number;
    name: string;
    phone: string;
    coach: string;
    seat: string;
    cart: CartItem[];
    totalAmount: number;
    status: OrderStatus;
    paymentMethod: PaymentMethod;
    paymentStatus: PaymentStatus;
    agentId?: number | null;
}

export interface StationInfo {
    id: number;
    name: string;
    code: string;
    arrivalTime: string;
    hasService: boolean;
}

export interface TrainRoute {
    trainNo: string;
    stations: StationInfo[];
}

export type UserRole = 'customer' | 'vendor' | 'agent' | 'admin';

export interface User {
    id?: number;
    mobile: string;
    email?: string;
    role: UserRole;
    name?: string;
    restaurantId?: number; // For vendors
    agentId?: number; // For agents
}

export interface Agent {
    id: number;
    name: string;
}

export interface PartnershipForm {
    stationName: string;
    restaurantName: string;
    restaurantMobile: string;
    ownerName: string;
    ownerMobile: string;
    email: string;
    distance: string;
    hasGst: boolean | null;
    hasFssai: boolean | null;
}