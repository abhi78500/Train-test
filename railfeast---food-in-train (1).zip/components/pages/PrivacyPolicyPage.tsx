import React from 'react';

const PrivacyPolicyPage: React.FC = () => {
    
    const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
        <section className="mb-8">
            <h2 className="text-2xl font-bold text-slate-800 mb-3 border-b pb-2">{title}</h2>
            <div className="space-y-4">{children}</div>
        </section>
    );

    return (
        <div className="bg-slate-50 py-12 sm:py-16">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl bg-white p-8 sm:p-12 rounded-lg shadow-lg">
                <header className="text-center mb-10">
                    <h1 className="text-4xl font-extrabold text-slate-900">Privacy Policy</h1>
                    <p className="mt-2 text-slate-500">Last updated: {new Date().toLocaleDateString()}</p>
                </header>

                <article className="text-slate-700 leading-relaxed">
                    <Section title="1. Introduction">
                        <p>
                            Welcome to RailFeast ("we," "our," "us"). We are committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our web application (the "Service"). Please read this privacy policy carefully. If you do not agree with the terms of this privacy policy, please do not access the service.
                        </p>
                    </Section>

                    <Section title="2. Information We Collect">
                        <p>We may collect information about you in a variety of ways. The information we may collect via the Service includes:</p>
                        <div>
                            <h3 className="font-semibold text-slate-800 mb-2">Personal Data</h3>
                            <p>
                                Personally identifiable information, such as your name, mobile number, email address (optional), and delivery details (coach and seat number) that you voluntarily give to us when you place an order or register with us.
                            </p>
                        </div>
                         <div>
                            <h3 className="font-semibold text-slate-800 mb-2">Journey Information</h3>
                            <p>
                                Information related to your train journey, such as PNR number or Train number, which you provide to find available services. This data is used solely for the purpose of identifying your route and relevant delivery stations.
                            </p>
                        </div>
                         <div>
                            <h3 className="font-semibold text-slate-800 mb-2">Order History</h3>
                            <p>
                                For logged-in users, we maintain a history of your past orders, including items ordered, restaurant details, and total amount, to provide you with a convenient way to review your past purchases and reorder.
                            </p>
                        </div>
                    </Section>

                    <Section title="3. How We Use Your Information">
                        <p>Having accurate information about you permits us to provide you with a smooth, efficient, and customized experience. Specifically, we may use information collected about you via the Service to:</p>
                        <ul className="list-disc list-inside space-y-2 pl-4">
                            <li>Create and manage your account.</li>
                            <li>Process your orders and deliver them to your seat.</li>
                            <li>Email you regarding your account or order (if email is provided).</li>
                            <li>Send you a confirmation and updates about your order via SMS or other notifications.</li>
                            <li>Fulfill and manage purchases, orders, payments, and other transactions related to the Service.</li>
                            <li>Maintain your order history for your convenience.</li>
                        </ul>
                    </Section>

                    <Section title="4. Disclosure of Your Information">
                        <p>We do not share your personal information with third parties except as described in this Privacy Policy. We may share information we have collected about you in certain situations:</p>
                         <ul className="list-disc list-inside space-y-2 pl-4">
                            <li><span className="font-semibold">With Restaurant Partners:</span> We share necessary order details (not including your full mobile number unless required for delivery coordination) with the restaurants you order from to enable them to prepare and package your meal.</li>
                            <li><span className="font-semibold">By Law or to Protect Rights:</span> If we believe the release of information about you is necessary to respond to legal process, to investigate or remedy potential violations of our policies, or to protect the rights, property, and safety of others.</li>
                        </ul>
                    </Section>
                    
                    <Section title="5. Security of Your Information">
                         <p>
                            We use administrative, technical, and physical security measures to help protect your personal information. While we have taken reasonable steps to secure the personal information you provide to us, please be aware that despite our efforts, no security measures are perfect or impenetrable, and no method of data transmission can be guaranteed against any interception or other type of misuse.
                        </p>
                    </Section>

                    <Section title="6. Contact Us">
                        <p>
                           If you have questions or comments about this Privacy Policy, please contact us at: <a href="mailto:privacy@railfeast.example.com" className="text-primary-600 hover:underline">privacy@railfeast.example.com</a>
                        </p>
                    </Section>
                </article>
            </div>
        </div>
    );
};

export default PrivacyPolicyPage;