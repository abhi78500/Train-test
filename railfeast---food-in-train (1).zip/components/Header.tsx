import React from 'react';
import { TrainIcon, CartIcon, MenuIcon } from './IconComponents';

interface HeaderProps {
    onLogoClick: () => void;
    cartCount: number;
    onMenuClick: () => void;
    onCartClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onLogoClick, cartCount, onMenuClick, onCartClick }) => {
    return (
        <header className="bg-white/80 shadow-md backdrop-blur-sm sticky top-0 z-30">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <div className="flex items-center gap-4">
                        <button 
                            onClick={onMenuClick} 
                            className="p-2 -ml-2 text-slate-600 rounded-full hover:bg-slate-100"
                            aria-label="Open menu"
                        >
                            <MenuIcon className="h-6 w-6" />
                        </button>
                        <div 
                            className="flex items-center gap-2 cursor-pointer"
                            onClick={onLogoClick}
                        >
                            <TrainIcon className="h-8 w-8 text-primary-600" />
                            <span className="text-2xl font-bold text-primary-700 tracking-tight">RailFeast</span>
                        </div>
                    </div>
                    <button
                        onClick={onCartClick}
                        className="group flex items-center gap-2 rounded-lg p-2 transition-colors hover:bg-slate-100"
                        aria-label={`View cart, ${cartCount} items`}
                    >
                        <div className="relative">
                            <CartIcon className="h-7 w-7 text-slate-600 transition-colors group-hover:text-primary-600" />
                            {cartCount > 0 && (
                                 <span className="absolute -top-2 -right-2 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-medium text-white">
                                    {cartCount}
                                </span>
                            )}
                        </div>
                        <span className="hidden sm:inline font-semibold text-slate-700 transition-colors group-hover:text-primary-700">My Cart</span>
                    </button>
                </div>
            </div>
        </header>
    );
};

export default Header;