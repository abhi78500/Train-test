import React from 'react';
import { OrderDetails } from '../../types';

interface ConfirmationPageProps {
    orderDetails: OrderDetails;
    onStartOver: () => void;
}

const ConfirmationPage: React.FC<ConfirmationPageProps> = ({ orderDetails, onStartOver }) => {
    return (
        <div className="bg-primary-50 min-h-screen flex items-center justify-center">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
                <div className="bg-white max-w-2xl mx-auto p-8 sm:p-12 rounded-2xl shadow-2xl">
                    <svg className="w-20 h-20 text-green-500 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 mt-6">Order Delivered!</h1>
                    <p className="text-slate-600 mt-2">Order ID: <span className="font-semibold text-slate-700 font-mono">{orderDetails.id}</span></p>
                    <p className="text-slate-600 mt-4 text-lg">
                        Thank you, {orderDetails.name}! We hope you enjoyed your meal.
                    </p>
                    <div className="text-left bg-slate-50 border border-slate-200 rounded-lg p-6 mt-8 space-y-4">
                        <div className="flex justify-between">
                            <span className="font-semibold text-slate-700">Total Amount Paid:</span>
                            <span className="font-bold text-primary-700 text-lg">₹{orderDetails.totalAmount}</span>
                        </div>
                         <div className="flex justify-between">
                            <span className="font-semibold text-slate-700">Delivered to:</span>
                            <span className="font-bold text-slate-800">Coach: {orderDetails.coach}, Seat: {orderDetails.seat}</span>
                        </div>
                        <div className="flex justify-between">
                            <span className="font-semibold text-slate-700">Payment Method:</span>
                             <span className="font-bold text-slate-800">
                                {orderDetails.paymentMethod === 'COD' ? 'Cash on Delivery' : 'Online'} ({orderDetails.paymentStatus})
                            </span>
                        </div>
                    </div>
                    <button
                        onClick={onStartOver}
                        className="mt-10 w-full sm:w-auto bg-primary-600 text-white font-bold py-3 px-8 rounded-md hover:bg-primary-700 transition-colors duration-300 shadow-md"
                    >
                        Place a New Order
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ConfirmationPage;