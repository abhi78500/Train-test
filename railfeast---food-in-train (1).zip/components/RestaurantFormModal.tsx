import React, { useState, useEffect } from 'react';
import { Restaurant } from '../types';
import { XMarkIcon, SparklesIcon } from './IconComponents';
import { generateRestaurantImage } from '../../services/geminiService';

interface RestaurantFormModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (restaurant: Restaurant) => void;
    restaurant: Restaurant | null; // null for 'add', object for 'edit'
}

const BLANK_RESTAURANT: Restaurant = {
  id: 0,
  name: '',
  station: '',
  stationCode: '',
  deliveryTime: '30-45 min',
  rating: 4.5,
  cuisine: 'North Indian, Jain',
  image: '',
  menu: [],
};

const FormField: React.FC<{ label: string; name: keyof Restaurant; value: string | number; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; required?: boolean; placeholder?: string, type?: string;}> = 
    ({ label, name, value, onChange, required, placeholder, type = 'text' }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-slate-700 mb-1">
            {label} {required && <span className="text-red-500">*</span>}
        </label>
        <input
            type={type}
            id={name}
            name={name}
            value={value}
            onChange={onChange}
            required={required}
            placeholder={placeholder}
            className="block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
        />
    </div>
);


const RestaurantFormModal: React.FC<RestaurantFormModalProps> = ({ isOpen, onClose, onSave, restaurant }) => {
    const [formData, setFormData] = useState<Restaurant>(BLANK_RESTAURANT);
    const [isGenerating, setIsGenerating] = useState(false);

    useEffect(() => {
        if (isOpen) {
            setFormData(restaurant ? { ...restaurant } : { ...BLANK_RESTAURANT });
            setIsGenerating(false);
        }
    }, [isOpen, restaurant]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // Simple validation
        if (!formData.name || !formData.station || !formData.stationCode) {
            alert('Please fill all required fields: Name, Station, and Station Code.');
            return;
        }
        onSave(formData);
    };

    const handleGenerateImage = async () => {
        if (!formData.name || !formData.cuisine) {
            alert("Please enter a restaurant name and cuisine to generate a relevant image.");
            return;
        }
        setIsGenerating(true);
        try {
            const prompt = `A delicious plate of ${formData.cuisine} food from the restaurant "${formData.name}". This dish is often served to train passengers. Professional food photography, warm lighting, appetizing, high detail, photorealistic.`;
            const imageUrl = await generateRestaurantImage(prompt);
            setFormData(prev => ({ ...prev, image: imageUrl }));
        } catch (error) {
            console.error(error);
            alert((error as Error).message || "An unknown error occurred while generating the image.");
        } finally {
            setIsGenerating(false);
        }
    };

    if (!isOpen) return null;
    
    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm z-50 flex items-start justify-center p-4 overflow-y-auto"
            onClick={onClose}
            role="dialog"
            aria-modal="true"
        >
            <div 
                className="bg-white rounded-2xl shadow-xl w-full max-w-lg transform transition-all my-8"
                onClick={(e) => e.stopPropagation()}
            >
                <form onSubmit={handleSubmit} className="p-6 sm:p-8">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-2xl font-bold text-slate-800">
                            {restaurant ? 'Edit Restaurant' : 'Add New Restaurant'}
                        </h2>
                        <button type="button" onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-primary-500">
                            <span className="sr-only">Close</span>
                            <XMarkIcon className="w-6 h-6" />
                        </button>
                    </div>

                    <div className="space-y-4">
                        <FormField label="Restaurant Name" name="name" value={formData.name} onChange={handleChange} required placeholder="e.g., Sattvik Rasoi"/>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <FormField label="Station Name" name="station" value={formData.station} onChange={handleChange} required placeholder="e.g., New Delhi"/>
                            <FormField label="Station Code" name="stationCode" value={formData.stationCode} onChange={handleChange} required placeholder="e.g., NDLS"/>
                        </div>
                         <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <FormField label="Cuisine" name="cuisine" value={formData.cuisine} onChange={handleChange} placeholder="e.g., North Indian, Jain"/>
                            <FormField label="Avg. Delivery Time" name="deliveryTime" value={formData.deliveryTime} onChange={handleChange} placeholder="e.g., 30-45 min"/>
                        </div>
                        <div>
                            <label htmlFor="image" className="block text-sm font-medium text-slate-700 mb-1">Image URL</label>
                            <input
                                type="text"
                                id="image"
                                name="image"
                                value={formData.image}
                                onChange={handleChange}
                                placeholder="Enter URL or generate with AI"
                                className="block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                            />
                             <button 
                                type="button" 
                                onClick={handleGenerateImage}
                                disabled={isGenerating}
                                className="mt-2 w-full flex items-center justify-center gap-2 px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:bg-primary-300 disabled:cursor-wait"
                            >
                                <SparklesIcon className="w-5 h-5"/>
                                {isGenerating ? 'Generating...' : 'Generate Image with AI'}
                            </button>
                        </div>

                        {formData.image && (
                            <div className="mt-2">
                                <p className="text-sm font-medium text-slate-700 mb-1">Image Preview</p>
                                <img src={formData.image} alt="Restaurant preview" className="w-full h-48 object-cover rounded-md bg-slate-100" />
                            </div>
                        )}
                        <p className="text-xs text-slate-500">You can provide a URL or generate an AI image. If left blank, a default placeholder image will be used.</p>
                    </div>
                    
                    <div className="mt-8 flex justify-end gap-4">
                        <button 
                            type="button" 
                            onClick={onClose} 
                            className="px-6 py-2 rounded-md font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors"
                        >
                            Cancel
                        </button>
                        <button 
                            type="submit" 
                            className="px-6 py-2 rounded-md font-semibold text-white bg-primary-600 hover:bg-primary-700 transition-colors shadow-sm"
                        >
                            Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default RestaurantFormModal;
