import React from 'react';
import { OrderDetails } from '../../types';
import { ReceiptIcon, TrainIcon } from '../IconComponents';

interface OrderHistoryPageProps {
    orderHistory: OrderDetails[];
    onViewDetails: (order: OrderDetails) => void;
    onGoHome: () => void;
}

const OrderHistoryCard: React.FC<{ order: OrderDetails; onViewDetails: (order: OrderDetails) => void; }> = ({ order, onViewDetails }) => (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 p-6">
        <div className="flex flex-col sm:flex-row justify-between sm:items-center border-b border-slate-200 pb-4 mb-4">
            <div>
                <p className="text-sm text-slate-500">Order ID</p>
                <p className="font-bold font-mono text-slate-800">{order.id}</p>
            </div>
            <p className="text-sm text-slate-500 mt-2 sm:mt-0">{new Date(order.date).toLocaleString()}</p>
        </div>
        <div className="flex items-center gap-4">
            <TrainIcon className="w-8 h-8 text-primary-500 shrink-0"/>
            <div className="flex-grow">
                <p className="font-semibold text-slate-800">{order.restaurantName}</p>
                <p className="text-sm text-slate-600">Total: <span className="font-bold">₹{order.totalAmount}</span></p>
            </div>
             <button
                onClick={() => onViewDetails(order)}
                className="bg-primary-100 text-primary-700 font-bold py-2 px-4 rounded-md hover:bg-primary-200 transition-colors"
            >
                View Bill
            </button>
        </div>
    </div>
);


const OrderHistoryPage: React.FC<OrderHistoryPageProps> = ({ orderHistory, onViewDetails, onGoHome }) => {
    return (
        <div className="bg-slate-100 min-h-[calc(100vh-8rem)] py-12">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <h1 className="text-3xl font-extrabold text-slate-900 mb-8 text-center">Your Order History</h1>
                {orderHistory.length > 0 ? (
                    <div className="max-w-2xl mx-auto space-y-6">
                        {orderHistory.map(order => (
                           <OrderHistoryCard key={order.id} order={order} onViewDetails={onViewDetails} />
                        ))}
                    </div>
                ) : (
                    <div className="text-center bg-white max-w-lg mx-auto p-10 rounded-xl shadow-md">
                        <ReceiptIcon className="w-20 h-20 text-slate-300 mx-auto" />
                        <h2 className="text-xl font-bold text-slate-700 mt-6">No Past Orders Found</h2>
                        <p className="text-slate-500 mt-2">Looks like you haven't placed an order with us yet. Let's change that!</p>
                        <button
                            onClick={onGoHome}
                            className="mt-8 bg-primary-600 text-white font-bold py-3 px-8 rounded-md hover:bg-primary-700 transition-colors duration-300 shadow-md"
                        >
                            Order Food Now
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default OrderHistoryPage;