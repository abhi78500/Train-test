import React, { useState, useEffect, useRef } from 'react';
import { Restaurant, MenuItem } from '../types';
import { ArrowDownTrayIcon, ArrowUpTrayIcon } from './IconComponents';
import * as XLSX from 'xlsx';


interface MenuEditorProps {
    restaurant: Restaurant;
    onSave: (restaurant: Restaurant) => void;
}

const BLANK_MENU_ITEM: Omit<MenuItem, 'id'> = {
    name: '',
    description: '',
    price: 0,
    veg: true,
    image: '',
};

const MenuItemForm: React.FC<{
    item: MenuItem | Omit<MenuItem, 'id'>;
    onSave: (item: MenuItem | Omit<MenuItem, 'id'>) => void;
    onCancel: () => void;
}> = ({ item, onSave, onCancel }) => {
    const [formData, setFormData] = useState(item);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value, type } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: type === 'number' ? parseFloat(value) || 0 : value,
        }));
    };
    
     const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, checked } = e.target;
        setFormData(prev => ({ ...prev, [name]: checked }));
    };


    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.name || formData.price <= 0) {
            alert('Please provide a valid name and price for the item.');
            return;
        }
        onSave(formData);
    };

    return (
        <form onSubmit={handleSubmit} className="bg-slate-100 p-4 rounded-lg my-4 space-y-4 border border-slate-200">
            <h3 className="text-lg font-bold text-slate-800">{'id' in item ? 'Edit Menu Item' : 'Add New Menu Item'}</h3>
            <div>
                <label htmlFor="name" className="block text-sm font-medium text-slate-700">Name</label>
                <input type="text" name="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm" />
            </div>
            <div>
                <label htmlFor="description" className="block text-sm font-medium text-slate-700">Description</label>
                <textarea name="description" value={formData.description} onChange={handleChange} required rows={2} className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm" />
            </div>
            <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label htmlFor="price" className="block text-sm font-medium text-slate-700">Price (₹)</label>
                    <input type="number" name="price" value={formData.price} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm" />
                </div>
                <div>
                     <label htmlFor="image" className="block text-sm font-medium text-slate-700">Image URL</label>
                    <input type="text" name="image" value={formData.image} onChange={handleChange} placeholder="Optional" className="mt-1 block w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm" />
                </div>
            </div>
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <input type="checkbox" id="veg" name="veg" checked={formData.veg} onChange={handleCheckboxChange} className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500" />
                    <label htmlFor="veg" className="text-sm font-medium text-slate-700">Pure Veg / Jain</label>
                </div>
                <div className="flex justify-end gap-2">
                    <button type="button" onClick={onCancel} className="px-4 py-2 rounded-md font-semibold text-slate-700 bg-slate-200 hover:bg-slate-300">Cancel</button>
                    <button type="submit" className="px-4 py-2 rounded-md font-semibold text-white bg-primary-600 hover:bg-primary-700">Save Item</button>
                </div>
            </div>
        </form>
    );
};

const MenuEditor: React.FC<MenuEditorProps> = ({ restaurant, onSave }) => {
    const [menu, setMenu] = useState<MenuItem[]>([]);
    const [editingItem, setEditingItem] = useState<MenuItem | Omit<MenuItem, 'id'> | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        // Deep copy menu to prevent modifying original state until save
        setMenu(JSON.parse(JSON.stringify(restaurant.menu.sort((a,b) => a.id - b.id))));
        setEditingItem(null); // Close form when restaurant changes
    }, [restaurant]);

    const handleAddNew = () => {
        setEditingItem(BLANK_MENU_ITEM);
    };

    const handleEdit = (item: MenuItem) => {
        setEditingItem(item);
    };

    const handleDelete = (itemId: number) => {
        if (window.confirm('Are you sure you want to delete this item?')) {
            setMenu(prev => prev.filter(item => item.id !== itemId));
        }
    };

    const handleSaveItem = (itemData: MenuItem | Omit<MenuItem, 'id'>) => {
        if ('id' in itemData) { // Editing existing
            setMenu(prev => prev.map(item => item.id === itemData.id ? itemData : item));
        } else { // Adding new
            const newId = menu.length > 0 ? (Math.max(...menu.map(i => i.id)) + 1) : (restaurant.id * 100) + 1;
            const newItem: MenuItem = { ...itemData, id: newId };
            setMenu(prev => [...prev, newItem]);
        }
        setEditingItem(null);
    };

    const handleSaveChanges = () => {
        onSave({ ...restaurant, menu });
    };

    const handleDownloadExcel = () => {
        const dataToExport = menu.map(item => ({
            id: item.id,
            name: item.name,
            description: item.description,
            price: item.price,
            veg: item.veg,
            image: item.image || ''
        }));

        const ws = XLSX.utils.json_to_sheet(dataToExport);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, "Menu");
        XLSX.writeFile(wb, `menu_${restaurant.name.replace(/\s+/g, '_')}.xlsx`);
    };

    const handleUploadClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = e.target?.result;
                const workbook = XLSX.read(data, { type: 'array' });
                const sheetName = workbook.SheetNames[0];
                const worksheet = workbook.Sheets[sheetName];
                const json: any[] = XLSX.utils.sheet_to_json(worksheet);

                const parsedMenu: MenuItem[] = json.map((row: any, index: number) => {
                    if (!row.name || isNaN(parseFloat(row.price))) {
                        throw new Error(`Invalid data in row ${index + 2}: 'name' and 'price' are required.`);
                    }
                    const vegValue = String(row.veg).toLowerCase();
                    const isVeg = ['true', '1', 'yes', 'jain'].includes(vegValue);

                    return {
                        id: parseInt(row.id) || 0, // Use 0 for new items
                        name: String(row.name),
                        description: String(row.description || ''),
                        price: parseFloat(row.price),
                        veg: isVeg,
                        image: String(row.image || ''),
                    };
                });
                
                let maxId = Math.max(0, ...menu.map(i => i.id), ...parsedMenu.map(i => i.id));
                const menuWithIds = parsedMenu.map(item => item.id === 0 ? { ...item, id: ++maxId } : item);

                setMenu(menuWithIds);
                alert(`${menuWithIds.length} menu items loaded from Excel. Review the changes and click "Save All Changes" to finalize.`);
            } catch (error) {
                console.error("Error processing Excel file:", error);
                alert(`Failed to process Excel file. Please ensure it has columns: id (optional), name, description, price, veg, image.\nError: ${error instanceof Error ? error.message : 'Unknown error'}`);
            } finally {
                if (event.target) event.target.value = '';
            }
        };
        reader.readAsArrayBuffer(file);
    };


    return (
        <div>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-slate-800">Menu for {restaurant.name}</h2>
            </div>
            
            <div className="my-4 grid grid-cols-1 sm:grid-cols-3 gap-2">
                 <button onClick={handleDownloadExcel} className="flex items-center justify-center gap-2 w-full bg-blue-100 text-blue-700 font-bold py-2 px-4 rounded-md hover:bg-blue-200 transition-colors">
                    <ArrowDownTrayIcon className="w-5 h-5"/>
                    <span>Download Menu</span>
                </button>
                 <button onClick={handleUploadClick} className="flex items-center justify-center gap-2 w-full bg-green-100 text-green-700 font-bold py-2 px-4 rounded-md hover:bg-green-200 transition-colors">
                    <ArrowUpTrayIcon className="w-5 h-5" />
                    <span>Upload Menu</span>
                </button>
                 <button onClick={handleAddNew} className="w-full bg-primary-100 text-primary-700 font-bold py-2 px-4 rounded-md hover:bg-primary-200 border border-dashed border-primary-400 transition-colors">
                    + Add New Item Manually
                </button>
                <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept=".xlsx, .xls" />
            </div>

            {editingItem && (
                <MenuItemForm item={editingItem} onSave={handleSaveItem} onCancel={() => setEditingItem(null)} />
            )}
            
            <div className="space-y-2">
                {menu.map(item => (
                    <div key={item.id} className="bg-white p-3 rounded-lg border flex items-center gap-4">
                       <img src={item.image || `https://picsum.photos/seed/${item.id}/200`} alt={item.name} className="w-16 h-16 object-cover rounded-md flex-shrink-0" />
                        <div className="flex-grow">
                            <h4 className="font-bold text-slate-800">{item.name}</h4>
                            <p className="text-sm text-slate-500">{item.description}</p>
                            <p className="text-sm font-semibold text-primary-700 mt-1">₹{item.price}</p>
                        </div>
                        <div className="flex flex-col gap-2 flex-shrink-0">
                            <button onClick={() => handleEdit(item)} className="text-xs font-medium text-blue-600 hover:text-blue-800 px-2 py-1 bg-blue-50 rounded">Edit</button>
                            <button onClick={() => handleDelete(item.id)} className="text-xs font-medium text-red-600 hover:text-red-800 px-2 py-1 bg-red-50 rounded">Delete</button>
                        </div>
                    </div>
                ))}
                 {menu.length === 0 && !editingItem && <p className="text-slate-500 text-center py-8">This restaurant has no menu items yet.</p>}
            </div>

            <div className="mt-6 pt-6 border-t">
                 <button type="button" onClick={handleSaveChanges} className="w-full px-6 py-3 rounded-md font-semibold text-white bg-primary-600 hover:bg-primary-700 shadow-md">
                    Save All Changes to Menu
                </button>
            </div>
        </div>
    );
};

export default MenuEditor;