import React from 'react';
import { TrainIcon } from '../IconComponents';

const AboutUsPage: React.FC = () => {
    return (
        <div className="bg-white py-12 sm:py-16">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
                <header className="text-center mb-12">
                    <TrainIcon className="w-16 h-16 text-primary-600 mx-auto mb-4"/>
                    <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight">About RailFeast</h1>
                    <p className="mt-4 text-xl text-slate-600">Connecting Journeys with Sattvic Flavors</p>
                </header>

                <article className="prose-lg max-w-none text-slate-700 space-y-6 leading-relaxed">
                    <p className="text-lg">
                        Train journeys in India are an experience in themselves—a tapestry of changing landscapes, diverse cultures, and shared stories. However, for too long, one crucial aspect of this experience, especially for those with specific dietary needs like Jainism, has been a source of compromise: food. Passengers often faced a choice between unhygienic pantry car meals or the uncertainty of platform vendors. We believed there had to be a better way.
                    </p>

                    <section>
                        <h2 className="text-3xl font-bold text-slate-800 mt-10 mb-4 border-b pb-2">Our Mission</h2>
                        <p>
                            Our mission at RailFeast is simple: to revolutionize the on-train dining experience for the vegetarian and Jain communities. We are dedicated to providing passengers with hot, fresh, and pure sattvic meals from trusted FSSAI-approved kitchens, delivered right to their seat. We aim to make every train journey a delightful culinary adventure, ensuring that pure food is no longer a luxury but a standard part of travel.
                        </p>
                    </section>
                    
                    <section>
                        <h2 className="text-3xl font-bold text-slate-800 mt-10 mb-4 border-b pb-2">How It Started</h2>
                        <p>
                            RailFeast was born from a simple idea shared between a group of friends on a cross-country train trip. Frustrated with the limited and unreliable food options that met their Jain dietary principles, we wondered, "What if we could order from trusted, pure-veg kitchens in the cities our train passes through?" This spark of an idea grew into a passionate project. We spent months building a robust technological platform, forging partnerships with certified Jain and vegetarian restaurants, and designing a seamless delivery network that works in sync with the Indian Railways schedule.
                        </p>
                    </section>
                    
                    <section>
                        <h2 className="text-3xl font-bold text-slate-800 mt-10 mb-4 border-b pb-2">Our Promise</h2>
                        <ul className="list-disc list-inside space-y-2 pl-4">
                            <li><span className="font-semibold">Purity & Hygiene:</span> We partner exclusively with top-rated, FSSAI-approved restaurants that adhere to the strictest hygiene and Jain cooking standards.</li>
                            <li><span className="font-semibold">Sattvic & Delicious:</span> Our menus are carefully curated to offer a wide variety of Jain dishes (no onion, garlic, or root vegetables) that are both delicious and wholesome.</li>
                            <li><span className="font-semibold">Timely Delivery:</span> Our real-time train tracking technology ensures your meal arrives fresh and on time, every time.</li>
                            <li><span className="font-semibold">Customer Delight:</span> We are committed to providing exceptional service and support throughout your ordering experience.</li>
                        </ul>
                    </section>

                    <footer className="text-center mt-12 pt-8 border-t">
                        <p className="text-lg font-semibold text-slate-800">Thank you for choosing RailFeast.</p>
                        <p className="text-slate-600">We look forward to serving you on your next journey!</p>
                    </footer>
                </article>
            </div>
        </div>
    );
};

export default AboutUsPage;