
import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer className="bg-slate-800 text-slate-300 mt-16">
            <div className="container mx-auto py-8 px-4 sm:px-6 lg:px-8">
                <div className="text-center">
                    <p>&copy; {new Date().getFullYear()} RailFeast. All Rights Reserved.</p>
                    <div className="flex justify-center gap-4 mt-4">
                        <a href="#" className="hover:text-white">About Us</a>
                        <a href="#" className="hover:text-white">Contact</a>
                        <a href="#" className="hover:text-white">FAQ</a>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
