
import React, { useMemo } from 'react';
import { User, OrderDetails, OrderStatus } from '../../types';

interface AgentDashboardPageProps {
    user: User | null;
    orders: OrderDetails[];
    onUpdateStatus: (orderId: string, status: OrderStatus) => void;
}

const getStatusColor = (status: OrderStatus) => {
    switch (status) {
        case 'Preparing': return 'bg-indigo-100 text-indigo-800';
        case 'Out for Delivery': return 'bg-purple-100 text-purple-800';
        case 'Delivered': return 'bg-green-100 text-green-800';
        default: return 'bg-slate-100 text-slate-800';
    }
};

const AgentDashboardPage: React.FC<AgentDashboardPageProps> = ({ user, orders, onUpdateStatus }) => {
    
    const assignedOrders = useMemo(() => {
        return orders
            .filter(order => order.agentId === user?.agentId && (order.status === 'Preparing' || order.status === 'Out for Delivery'))
            .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    }, [orders, user]);
    
    const readyForPickup = assignedOrders.filter(o => o.status === 'Preparing');
    const onTheWay = assignedOrders.filter(o => o.status === 'Out for Delivery');

    if (!user || user.role !== 'agent' || !user.agentId) {
        return <div className="p-8 text-center text-red-500">Access Denied. You must be an agent to view this page.</div>;
    }

    const OrderCard: React.FC<{order: OrderDetails}> = ({order}) => (
        <div className="bg-white p-4 rounded-lg shadow-md space-y-3">
            <div className="flex justify-between items-start">
                 <div>
                    <p className="font-bold text-slate-800">{order.id}</p>
                    <p className="text-sm font-semibold text-brand-700">{order.restaurantName}</p>
                </div>
                 <span className={`px-2 py-1 text-xs font-bold rounded-full ${getStatusColor(order.status)}`}>
                    {order.status}
                </span>
            </div>
            <div className="text-sm border-t pt-3">
                <p><span className="font-semibold">Customer:</span> {order.name}</p>
                <p><span className="font-semibold">Deliver to:</span> Coach {order.coach}, Seat {order.seat}</p>
                <p><span className="font-semibold">Contact:</span> {order.phone}</p>
            </div>
            {order.status === 'Preparing' && (
                <button
                    onClick={() => onUpdateStatus(order.id, 'Out for Delivery')}
                    className="w-full bg-purple-500 text-white font-bold py-2 rounded-md hover:bg-purple-600 transition-colors"
                >
                    Mark Picked Up (Out for Delivery)
                </button>
            )}
            {order.status === 'Out for Delivery' && (
                <button
                    onClick={() => onUpdateStatus(order.id, 'Delivered')}
                    className="w-full bg-green-500 text-white font-bold py-2 rounded-md hover:bg-green-600 transition-colors"
                >
                    Mark as Delivered
                </button>
            )}
        </div>
    );

    return (
        <div className="bg-slate-100 min-h-screen p-4 sm:p-6 lg:p-8">
            <div className="max-w-4xl mx-auto">
                <header className="mb-8">
                    <h1 className="text-3xl font-extrabold text-slate-900">Agent Dashboard</h1>
                    <p className="text-slate-600 mt-1">Welcome, {user.name}. Here are your assigned tasks.</p>
                </header>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                    <div className="space-y-4">
                        <h2 className="text-xl font-bold text-slate-800 border-b-2 border-orange-400 pb-2">Ready for Pickup ({readyForPickup.length})</h2>
                        <div className="space-y-4 max-h-[70vh] overflow-y-auto p-1">
                            {readyForPickup.length > 0 ? readyForPickup.map(order => <OrderCard key={order.id} order={order} />) : <p className="text-slate-500 text-center py-4">No orders waiting for pickup.</p>}
                        </div>
                    </div>
                    <div className="space-y-4">
                        <h2 className="text-xl font-bold text-slate-800 border-b-2 border-purple-400 pb-2">Out for Delivery ({onTheWay.length})</h2>
                        <div className="space-y-4 max-h-[70vh] overflow-y-auto p-1">
                            {onTheWay.length > 0 ? onTheWay.map(order => <OrderCard key={order.id} order={order} />) : <p className="text-slate-500 text-center py-4">No orders currently out for delivery.</p>}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AgentDashboardPage;
