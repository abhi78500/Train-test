import React, { useMemo, useEffect } from 'react';
import { OrderDetails } from '../../types';
import { TrainIcon, CheckCircleIcon, DeliveryPersonIcon, FoodBoxIcon } from '../IconComponents';

interface TrackOrderPageProps {
    order: OrderDetails | null;
    onOrderDelivered: (orderId: string) => void;
    onGoHome: () => void;
}

const STATUSES = [
    { name: 'Pending', index: 0 },
    { name: 'Accepted', index: 1 },
    { name: 'Preparing', index: 2 },
    { name: 'Out for Delivery', index: 3 },
    { name: 'Delivered', index: 4 },
];

const TrackOrderPage: React.FC<TrackOrderPageProps> = ({ order, onOrderDelivered, onGoHome }) => {
    
    useEffect(() => {
        if (order?.status === 'Delivered') {
            const timer = setTimeout(() => {
                onOrderDelivered(order.id);
            }, 3000); // Wait 3 seconds on delivered screen before navigating
            return () => clearTimeout(timer);
        }
    }, [order, onOrderDelivered]);

    const currentStatusInfo = useMemo(() => {
        return STATUSES.find(s => s.name === order?.status) || { name: 'Pending', index: 0 };
    }, [order]);
    
    const progressPercentage = useMemo(() => {
        if (!order) return 0;
        const statusIndex = currentStatusInfo.index;
        if (statusIndex === 0) return 0;
        if (statusIndex === STATUSES.length - 1) return 100;
        return (statusIndex / (STATUSES.length - 2)) * 100; // Adjust for 0-indexed and Delivered state
    }, [order, currentStatusInfo]);


    if (!order) {
        return (
            <div className="bg-slate-50 min-h-[60vh] flex flex-col items-center justify-center">
                <div className="text-center p-8">
                    <FoodBoxIcon className="w-24 h-24 text-slate-300 mx-auto" />
                    <h1 className="text-2xl font-bold text-slate-700 mt-6">You have no active orders to track.</h1>
                    <p className="text-slate-500 mt-2">Ready to order? Let's find some food!</p>
                    <button
                        onClick={onGoHome}
                        className="mt-8 bg-primary-600 text-white font-bold py-3 px-8 rounded-md hover:bg-primary-700 transition-colors duration-300 shadow-md"
                    >
                        Go to Homepage
                    </button>
                </div>
            </div>
        );
    }
    
    const displayStatuses = STATUSES.slice(0, -1); // Don't show "Delivered" in the progress bar itself

    return (
        <div className="bg-slate-100 py-12 sm:py-16">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-xl p-6 sm:p-8">
                    <div className="text-center">
                        <h1 className="text-3xl font-extrabold text-slate-900">Tracking Your Order</h1>
                        <p className="mt-2 text-slate-500 font-mono">ID: <span className="font-bold text-slate-700">{order.id}</span></p>
                        <p className="mt-2 text-slate-600">
                            Delivering to <span className="font-bold text-primary-700">Coach {order.coach}, Seat {order.seat}</span>
                        </p>
                    </div>

                    <div className="mt-12">
                         <div className="relative">
                             <div className="absolute -top-6 z-10 transition-all duration-1000 ease-in-out" style={{ left: `calc(${progressPercentage}% - 16px)` }}>
                                <TrainIcon className="w-8 h-8 text-primary-600" />
                            </div>
                            <div className="relative h-2 rounded-full bg-slate-200">
                                <div className="absolute top-0 left-0 h-2 rounded-full bg-primary-500 transition-all duration-1000 ease-in-out" style={{ width: `${progressPercentage}%` }}></div>
                            </div>
                            <div className="flex justify-between mt-3 text-xs sm:text-sm">
                                {displayStatuses.map((status, index) => {
                                    const isCompleted = currentStatusInfo.index >= status.index;
                                    return (
                                        <div key={status.name} className={`flex-1 text-center ${isCompleted ? 'font-semibold text-primary-700' : 'text-slate-500'}`}>
                                            <div className="relative flex justify-center mb-1">
                                                <div className={`w-4 h-4 rounded-full transition-colors ${isCompleted ? 'bg-primary-500' : 'bg-slate-300'}`}>
                                                     {currentStatusInfo.index > status.index && <CheckCircleIcon className="w-4 h-4 text-white"/>}
                                                     {currentStatusInfo.index === status.index && status.name !== 'Delivered' && <div className="animate-ping h-4 w-4 rounded-full absolute bg-primary-400"></div>}
                                                </div>
                                            </div>
                                            {status.name}
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    </div>
                    
                    <div className="mt-12 p-4 bg-primary-50 border-l-4 border-primary-500 rounded-r-lg">
                        <p className={`text-lg font-semibold text-center ${order.status !== 'Delivered' ? 'text-primary-800 animate-pulse' : 'text-green-700'}`}>
                            Current Status: {order.status}
                        </p>
                    </div>

                    <div className="mt-10 flex items-center gap-4 bg-blue-50 p-4 rounded-lg">
                        <style>{`
                            @keyframes slow-bounce {
                                0%, 100% { transform: translateY(-3%); }
                                50% { transform: translateY(0); }
                            }
                            .animate-slow-bounce { animation: slow-bounce 3s ease-in-out infinite; }
                        `}</style>
                        <DeliveryPersonIcon className="w-24 h-24 sm:w-28 sm:h-28 shrink-0 animate-slow-bounce" />
                        <div className="relative flex-grow bg-white p-4 rounded-lg shadow-sm after:content-[''] after:absolute after:top-1/2 after:-left-3 after:transform after:-translate-y-1/2 after:border-8 after:border-transparent after:border-r-white">
                            <p className="text-sm sm:text-base text-slate-700 font-medium">"Please be on your seat, your order will be delivered right to you!"</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TrackOrderPage;