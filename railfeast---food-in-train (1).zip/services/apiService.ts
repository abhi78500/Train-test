import { MOCK_RESTAURANTS, MOCK_TRAIN_ROUTES } from '../constants';
import { Restaurant, TrainRoute, PartnershipForm } from '../types';

// Simulate API latency
const API_DELAY = 750;

/**
 * Simulates fetching the route for a given train number from a backend API.
 * @param trainNo The 5-digit train number.
 * @returns A promise that resolves to the TrainRoute or null if not found.
 */
export const getTrainRoute = (trainNo: string): Promise<TrainRoute | null> => {
    console.log(`[API] Fetching route for train: ${trainNo}`);
    return new Promise(resolve => {
        setTimeout(() => {
            const route = MOCK_TRAIN_ROUTES.find(r => r.trainNo === trainNo) || null;
            if (route) {
                console.log(`[API] Found route for train: ${trainNo}`, route);
            } else {
                console.warn(`[API] No route found for train: ${trainNo}`);
            }
            resolve(route);
        }, API_DELAY);
    });
};

/**
 * Simulates fetching a list of restaurants for a given station code.
 * @param stationCode The code of the station (e.g., "NDLS").
 * @returns A promise that resolves to an array of Restaurants.
 */
export const getRestaurantsByStation = (stationCode: string): Promise<Restaurant[]> => {
    console.log(`[API] Fetching restaurants for station: ${stationCode}`);
    return new Promise(resolve => {
        setTimeout(() => {
            const restaurants = MOCK_RESTAURANTS.filter(r => r.stationCode === stationCode);
            console.log(`[API] Found ${restaurants.length} restaurants for ${stationCode}`, restaurants);
            resolve(restaurants);
        }, API_DELAY * 1.5); // make it a bit slower
    });
};

/**
 * Simulates fetching a list of all/featured restaurants for the homepage.
 * @returns A promise that resolves to an array of Restaurants.
 */
export const getFeaturedRestaurants = (): Promise<Restaurant[]> => {
     console.log(`[API] Fetching all restaurants for homepage`);
     return new Promise(resolve => {
        setTimeout(() => {
            console.log(`[API] Found ${MOCK_RESTAURANTS.length} total restaurants.`);
            resolve(MOCK_RESTAURANTS);
        }, API_DELAY);
    });
};

/**
 * Simulates submitting the "Partner with Us" form.
 * @param formData The form data to submit.
 * @returns A promise that resolves to a success object.
 */
export const submitPartnershipForm = (formData: PartnershipForm): Promise<{ success: true }> => {
    console.log('[API] Submitting partnership form:', formData);
    return new Promise(resolve => {
        setTimeout(() => {
            console.log('[API] Form submitted successfully.');
            resolve({ success: true });
        }, 1500);
    });
};
