import React, { useState, useCallback, useEffect } from 'react';
import { Page, Restaurant, CartItem, OrderDetails, TrainRoute, StationInfo, User, OrderStatus, Agent, PaymentMethod } from './types';
import Header from './components/Header';
import Footer from './components/Footer';
import HomePage from './components/pages/HomePage';
import StationsPage from './components/pages/StationsPage';
import RestaurantsListPage from './components/pages/RestaurantsListPage';
import MenuPage from './components/pages/MenuPage';
import CheckoutPage from './components/pages/CheckoutPage';
import ConfirmationPage from './components/pages/ConfirmationPage';
import TrackOrderPage from './components/pages/TrackOrderPage';
import LoginModal from './components/LoginModal';
import { MOCK_TRAIN_ROUTES, MOCK_USERS, MOCK_AGENTS } from './constants';
import { getFeaturedRestaurants, getRestaurantsByStation, getTrainRoute } from './services/apiService';
import { SliderMenu } from './components/SliderMenu';
import OrderHistoryPage from './components/pages/OrderHistoryPage';
import OrderBillPage from './components/pages/OrderBillPage';
import AboutUsPage from './components/pages/AboutUsPage';
import PrivacyPolicyPage from './components/pages/PrivacyPolicyPage';
import TermsAndConditionsPage from './components/pages/TermsAndConditionsPage';
import PartnerWithUsPage from './components/pages/PartnerWithUsPage';
import AdminDashboardPage from './components/pages/AdminDashboardPage';
import VendorDashboardPage from './components/pages/VendorDashboardPage';
import AgentDashboardPage from './components/pages/AgentDashboardPage';
import PaymentGatewayModal from './components/PaymentGatewayModal';

const App: React.FC = () => {
    const [currentPage, setCurrentPage] = useState<Page>('home');
    const [pnr, setPnr] = useState<string>('');
    const [trainNo, setTrainNo] = useState<string>('');
    const [activeRoute, setActiveRoute] = useState<TrainRoute | null>(null);
    const [selectedStation, setSelectedStation] = useState<StationInfo | null>(null);
    const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);
    const [cart, setCart] = useState<CartItem[]>([]);
    
    // State for data fetched from APIs
    const [allOrders, setAllOrders] = useState<OrderDetails[]>([]);
    const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
    const [stationRestaurants, setStationRestaurants] = useState<Restaurant[]>([]);

    // Loading states
    const [isSearching, setIsSearching] = useState(false);
    const [isFetchingRestaurants, setIsFetchingRestaurants] = useState(false);
    const [isInitialLoading, setIsInitialLoading] = useState(true);

    const [activeOrder, setActiveOrder] = useState<OrderDetails | null>(null);
    const [selectedOrderForDetails, setSelectedOrderForDetails] = useState<OrderDetails | null>(null);
    const [isSliderOpen, setIsSliderOpen] = useState(false);
    const [user, setUser] = useState<User | null>(null);
    const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

    // Payment Flow State
    const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
    const [pendingOrderDetails, setPendingOrderDetails] = useState<Omit<OrderDetails, 'id' | 'date' | 'status'> | null>(null);
    
    const orderHistory = user?.role === 'customer' ? allOrders.filter(o => o.phone === user.mobile).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()) : [];

    useEffect(() => {
        const fetchInitialData = async () => {
            setIsInitialLoading(true);
            try {
                // In a real app, you might fetch initial orders, user session, etc.
                const allRestaurants = await getFeaturedRestaurants(); // Using this to populate homepage
                setRestaurants(allRestaurants);
            } catch (error) {
                console.error("Failed to load initial data", error);
                alert("Could not load initial data. Please refresh.");
            } finally {
                setIsInitialLoading(false);
            }
        };
        fetchInitialData();
    }, []);

    const navigateTo = (page: Page) => {
        window.scrollTo(0, 0);
        setCurrentPage(page);
    };

    const handleSearch = async (value: string, type: 'pnr' | 'train') => {
        const trainNumberToSearch = type === 'pnr' ? '12345' : value;
        
        setIsSearching(true);
        try {
            const route = await getTrainRoute(trainNumberToSearch);
            if (route) {
                if (type === 'pnr') setPnr(value); else setTrainNo(value);
                setActiveRoute(route);
                navigateTo('stations');
            } else {
                alert(`Could not find a route for ${type === 'pnr' ? 'PNR' : 'Train No.'} ${value}. Please try a different number.`);
            }
        } catch (error) {
             console.error("Error during train search:", error);
             alert("An error occurred while searching. Please try again.");
        } finally {
            setIsSearching(false);
        }
    };
    
    const handleSelectStation = async (station: StationInfo) => {
        if (station.hasService) {
            setIsFetchingRestaurants(true);
            setSelectedStation(station);
            navigateTo('restaurants');
            try {
                const availableRestaurants = await getRestaurantsByStation(station.code);
                setStationRestaurants(availableRestaurants);
            } catch (error) {
                 console.error(`Error fetching restaurants for ${station.name}:`, error);
                alert(`Could not load restaurants for ${station.name}. Please try again.`);
            } finally {
                setIsFetchingRestaurants(false);
            }
        }
    };

    const handleSelectRestaurant = (restaurant: Restaurant) => {
        setSelectedRestaurant(restaurant);
        navigateTo('menu');
    };

    const updateCart = useCallback((item: CartItem, quantity: number) => {
        setCart(prevCart => {
            const existingItem = prevCart.find(cartItem => cartItem.item.id === item.item.id);
            if (quantity <= 0) return prevCart.filter(cartItem => cartItem.item.id !== item.item.id);
            if (existingItem) return prevCart.map(cartItem => cartItem.item.id === item.item.id ? { ...cartItem, quantity } : cartItem);
            return [...prevCart, { ...item, quantity }];
        });
    }, []);

    const handleCheckout = (details: { name: string; phone: string; coach: string; seat: string; totalAmount: number; paymentMethod: PaymentMethod; }) => {
        if (!selectedRestaurant) {
            alert("An error occurred. No restaurant is selected.");
            navigateTo('home');
            return;
        }

        const { paymentMethod, ...deliveryDetails } = details;

        const orderBlueprint = {
            restaurantName: selectedRestaurant.name,
            restaurantId: selectedRestaurant.id,
            cart: cart,
            ...deliveryDetails
        };
    
        if (paymentMethod === 'Online') {
            setPendingOrderDetails({
                ...orderBlueprint,
                paymentMethod: 'Online',
                paymentStatus: 'Paid',
            });
            setIsPaymentModalOpen(true);
        } else { // COD
            const newOrder: OrderDetails = {
                id: `RF-${Date.now().toString().slice(-6)}`,
                date: new Date().toISOString(),
                status: 'Pending',
                paymentMethod: 'COD',
                paymentStatus: 'Unpaid',
                ...orderBlueprint,
            };
            
            setAllOrders(prev => [newOrder, ...prev]);
            setActiveOrder(newOrder);
            setCart([]);
            navigateTo('track_order');
        }
    };
    
    const handlePaymentSuccess = () => {
        if (!pendingOrderDetails) return;

        const newOrder: OrderDetails = {
            id: `RF-${Date.now().toString().slice(-6)}`,
            date: new Date().toISOString(),
            status: 'Pending',
            ...pendingOrderDetails
        } as OrderDetails;

        setAllOrders(prev => [newOrder, ...prev]);
        setActiveOrder(newOrder);
        setCart([]);
        setIsPaymentModalOpen(false);
        setPendingOrderDetails(null);
        navigateTo('track_order');
    };


    const handleOrderDelivered = (orderId: string) => {
        const deliveredOrder = allOrders.find(o => o.id === orderId);
        if(deliveredOrder) {
            setAllOrders(prevOrders => prevOrders.map(o => o.id === orderId ? {...o, paymentStatus: 'Paid'} : o));
            setActiveOrder(null);
            navigateTo('confirmation');
        }
    };

    const handleStartOver = () => {
        setPnr('');
        setTrainNo('');
        setActiveRoute(null);
        setSelectedStation(null);
        setSelectedRestaurant(null);
        setCart([]);
        setActiveOrder(null);
        navigateTo('home');
    };

    const handleMenuOpen = () => setIsSliderOpen(true);
    const handleMenuClose = () => setIsSliderOpen(false);

    const handleLoginClick = () => {
        handleMenuClose();
        setIsLoginModalOpen(true);
    };

    const handleLogout = () => {
        setUser(null);
        setSelectedOrderForDetails(null);
        handleMenuClose();
        handleStartOver();
    };

    const handleLoginSuccess = (loggedInUser: User) => {
        setUser(loggedInUser);
        setIsLoginModalOpen(false);
        // Redirect based on role
        switch(loggedInUser.role) {
            case 'admin':
                navigateTo('admin_dashboard');
                break;
            case 'vendor':
                navigateTo('vendor_dashboard');
                break;
            case 'agent':
                navigateTo('agent_dashboard');
                break;
            case 'customer':
                if (cart.length > 0) navigateTo('checkout');
                break;
            default:
                navigateTo('home');
        }
    };
    
    const handleProceedToCheckout = () => {
        if (user) navigateTo('checkout'); else setIsLoginModalOpen(true);
    };
    
    const handleCartClick = () => {
        if (cart.length > 0) {
            handleProceedToCheckout();
        }
    };

    const handleTrackOrderClick = () => {
        handleMenuClose();
        if(!activeOrder && orderHistory.length > 0) {
            const lastOrder = orderHistory[0];
            if(lastOrder.status !== 'Delivered' && lastOrder.status !== 'Cancelled') {
                setActiveOrder(lastOrder);
            }
        }
        navigateTo('track_order');
    };

    const handleOrderHistoryClick = () => {
        handleMenuClose();
        navigateTo('order_history');
    };
    
    const handleAboutUsClick = () => {
        handleMenuClose();
        navigateTo('about_us');
    };



    const handlePrivacyPolicyClick = () => {
        handleMenuClose();
        navigateTo('privacy_policy');
    };

    const handleTermsClick = () => {
        handleMenuClose();
        navigateTo('terms_conditions');
    };

    const handlePartnerWithUsClick = () => {
        handleMenuClose();
        navigateTo('partner_with_us');
    };
    
    const handleDashboardClick = () => {
        handleMenuClose();
        if (user) {
            switch(user.role) {
                case 'admin': navigateTo('admin_dashboard'); break;
                case 'vendor': navigateTo('vendor_dashboard'); break;
                case 'agent': navigateTo('agent_dashboard'); break;
                default: navigateTo('home');
            }
        }
    };

    const handleViewOrderDetails = (order: OrderDetails) => {
        setSelectedOrderForDetails(order);
        navigateTo('order_details');
    };

    const handleUpdateOrderStatus = (orderId: string, status: OrderStatus) => {
        setAllOrders(prevOrders => prevOrders.map(o => {
            if (o.id === orderId) {
                // If order is delivered via COD, mark as paid
                if (status === 'Delivered' && o.paymentMethod === 'COD') {
                    return {...o, status, paymentStatus: 'Paid'};
                }
                return {...o, status};
            }
            return o;
        }));
        if (activeOrder?.id === orderId) {
            setActiveOrder(prev => prev ? {...prev, status} : null);
        }
    };
    
    const handleAssignAgent = (orderId: string, agentId: number) => {
         setAllOrders(prevOrders => prevOrders.map(o => o.id === orderId ? {...o, agentId} : o));
    };

    const handleSaveRestaurant = (restaurantData: Restaurant) => {
        // In a real app, this would be an API call, and the API would return the updated list or item.
        // Here we just simulate updating our local state.
        const allRests = [...restaurants];
        const isUpdate = restaurantData.id > 0;

        if (isUpdate) {
            const index = allRests.findIndex(r => r.id === restaurantData.id);
            if (index !== -1) allRests[index] = restaurantData;
        } else {
            const newId = allRests.length > 0 ? Math.max(...allRests.map(r => r.id)) + 1 : 1;
            const newRestaurant: Restaurant = {
                ...restaurantData,
                id: newId,
                rating: restaurantData.rating || 4.5,
                menu: restaurantData.menu || [],
                image: restaurantData.image || `https://picsum.photos/seed/restaurant${newId}/400/300`,
            };
            allRests.unshift(newRestaurant);
        }
        setRestaurants(allRests);
    };

    const renderPage = () => {
        if (isInitialLoading) {
            return (
                <div className="flex justify-center items-center h-[calc(100vh-4rem)]">
                    <svg className="animate-spin h-10 w-10 text-primary-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                </div>
            );
        }

        switch (currentPage) {
            case 'home':
                return <HomePage onSearch={handleSearch} onSelectRestaurant={handleSelectRestaurant} restaurants={restaurants} isLoading={isSearching} />;
            case 'stations':
                if (activeRoute) return <StationsPage route={activeRoute} onSelectStation={handleSelectStation} />;
                break;
            case 'restaurants':
                if (selectedStation) {
                    return <RestaurantsListPage station={selectedStation} restaurants={stationRestaurants} onSelectRestaurant={handleSelectRestaurant} isLoading={isFetchingRestaurants} />;
                }
                break;
            case 'menu':
                if (selectedRestaurant) return <MenuPage restaurant={selectedRestaurant} cart={cart} updateCart={updateCart} onProceedToCheckout={handleProceedToCheckout} />;
                break;
            case 'checkout':
                return <CheckoutPage cart={cart} pnr={pnr} trainNo={trainNo} onPlaceOrder={handleCheckout} user={user} restaurant={selectedRestaurant}/>;
            case 'track_order':
                return <TrackOrderPage order={activeOrder} onOrderDelivered={handleOrderDelivered} onGoHome={handleStartOver} />;
            case 'confirmation':
                if(orderHistory.length > 0) return <ConfirmationPage orderDetails={orderHistory[0]} onStartOver={handleStartOver} />;
                break;
            case 'order_history':
                return <OrderHistoryPage orderHistory={orderHistory} onViewDetails={handleViewOrderDetails} onGoHome={handleStartOver} />;
            case 'order_details':
                return <OrderBillPage order={selectedOrderForDetails} onBack={() => navigateTo('order_history')} />;
            case 'about_us':
                return <AboutUsPage />;
            case 'privacy_policy':
                return <PrivacyPolicyPage />;
            case 'terms_conditions':
                return <TermsAndConditionsPage />;
            case 'partner_with_us':
                return <PartnerWithUsPage />;
            case 'admin_dashboard':
                return <AdminDashboardPage 
                    user={user} 
                    orders={allOrders} 
                    agents={MOCK_AGENTS} 
                    onUpdateStatus={handleUpdateOrderStatus} 
                    onAssignAgent={handleAssignAgent}
                    restaurants={restaurants}
                    onSaveRestaurant={handleSaveRestaurant}
                />;
            case 'vendor_dashboard':
                return <VendorDashboardPage user={user} orders={allOrders} onUpdateStatus={handleUpdateOrderStatus} />;
            case 'agent_dashboard':
                return <AgentDashboardPage user={user} orders={allOrders} onUpdateStatus={handleUpdateOrderStatus} />;
            default:
                return <HomePage onSearch={handleSearch} onSelectRestaurant={handleSelectRestaurant} restaurants={restaurants} isLoading={isSearching} />;
        }
        navigateTo('home');
        return null;
    };

    return (
        <div className="flex flex-col min-h-screen font-sans text-slate-800">
            <Header onLogoClick={handleStartOver} cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)} onMenuClick={handleMenuOpen} onCartClick={handleCartClick} />
            <SliderMenu 
                isOpen={isSliderOpen} 
                onClose={handleMenuClose} 
                user={user}
                onLoginClick={handleLoginClick}
                onLogout={handleLogout}
                activeOrder={activeOrder}
                onTrackOrderClick={handleTrackOrderClick}
                onOrderHistoryClick={handleOrderHistoryClick}
                onAboutUsClick={handleAboutUsClick}
                onPrivacyPolicyClick={handlePrivacyPolicyClick}
                onTermsClick={handleTermsClick}
                onPartnerWithUsClick={handlePartnerWithUsClick}
                onDashboardClick={handleDashboardClick}
            />
            <LoginModal isOpen={isLoginModalOpen} onClose={() => setIsLoginModalOpen(false)} onLoginSuccess={handleLoginSuccess} />
             <PaymentGatewayModal 
                isOpen={isPaymentModalOpen}
                onClose={() => setIsPaymentModalOpen(false)}
                onPaymentSuccess={handlePaymentSuccess}
                amount={pendingOrderDetails?.totalAmount || 0}
            />
            <main className="flex-grow">
                {renderPage()}
            </main>
            <Footer />
        </div>
    );
};

export default App;