import React, { useState, useMemo, useEffect } from 'react';
import { CartItem, User, Restaurant, PaymentMethod } from '../../types';
import { CashIcon, CreditCardIcon } from '../IconComponents';

interface CheckoutPageProps {
    cart: CartItem[];
    pnr: string;
    trainNo: string;
    onPlaceOrder: (details: { name: string; phone: string; coach: string; seat: string; totalAmount: number; paymentMethod: PaymentMethod }) => void;
    user: User | null;
    restaurant: Restaurant | null;
}

const PaymentOption: React.FC<{ method: PaymentMethod, label: string; icon: React.ReactNode; selected: boolean; onSelect: () => void }> = ({ method, label, icon, selected, onSelect }) => (
    <button
        type="button"
        onClick={onSelect}
        className={`flex items-center gap-4 p-4 border-2 rounded-lg transition-all duration-200 ${selected ? 'border-primary-500 bg-primary-50 shadow-md' : 'border-slate-300 bg-white hover:border-primary-400'}`}
        role="radio"
        aria-checked={selected}
    >
        <div className={`p-2 rounded-full ${selected ? 'bg-primary-500 text-white' : 'bg-slate-100 text-slate-600'}`}>
            {icon}
        </div>
        <div>
            <p className="font-bold text-slate-800 text-left">{label}</p>
            <p className="text-sm text-slate-500 text-left">{method === 'Online' ? 'Card, UPI, Net Banking' : 'Pay at your seat upon delivery'}</p>
        </div>
    </button>
);


const CheckoutPage: React.FC<CheckoutPageProps> = ({ cart, pnr, trainNo, onPlaceOrder, user, restaurant }) => {
    const [name, setName] = useState('');
    const [phone, setPhone] = useState('');
    const [coach, setCoach] = useState('');
    const [seat, setSeat] = useState('');
    const [paymentMethod, setPaymentMethod] = useState<PaymentMethod | null>(null);
    const [error, setError] = useState('');

    useEffect(() => {
        if (user) {
            setPhone(user.mobile);
            if (user.name) {
                setName(user.name);
            }
        }
    }, [user]);

    const totalAmount = useMemo(() => cart.reduce((sum, cartItem) => sum + cartItem.item.price * cartItem.quantity, 0), [cart]);
    const platformFee = 20;
    const finalTotal = totalAmount + platformFee;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!paymentMethod) {
            setError('Please select a payment method.');
            window.scrollTo(0, document.body.scrollHeight);
            return;
        }
        setError('');
        if (name && phone && coach && seat) {
            onPlaceOrder({ name, phone, coach, seat, totalAmount: finalTotal, paymentMethod });
        } else {
            alert('Please fill all the details.');
        }
    };

    if (cart.length === 0) {
        return (
            <div className="container mx-auto px-4 py-12 text-center">
                <h1 className="text-2xl font-bold">Your cart is empty.</h1>
                <p className="text-slate-600 mt-2">Please add items to your cart before proceeding to checkout.</p>
            </div>
        );
    }

    return (
        <div className="bg-slate-100 min-h-screen">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <h1 className="text-3xl font-extrabold text-slate-900 mb-8 text-center">Checkout</h1>
                 <form onSubmit={handleSubmit}>
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div className="lg:col-span-2 bg-white p-8 rounded-xl shadow-lg space-y-8">
                            
                            <div>
                                <h2 className="text-2xl font-bold text-slate-800 border-b pb-4 mb-6">Delivery Details</h2>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    {pnr ? (
                                        <div>
                                            <label htmlFor="pnr" className="block text-sm font-medium text-slate-700">PNR Number</label>
                                            <input type="text" id="pnr" value={pnr} readOnly className="mt-1 block w-full px-3 py-2 bg-slate-100 border border-slate-300 rounded-md shadow-sm cursor-not-allowed" />
                                        </div>
                                    ) : (
                                        <div>
                                            <label htmlFor="trainNo" className="block text-sm font-medium text-slate-700">Train Number</label>
                                            <input type="text" id="trainNo" value={trainNo} readOnly className="mt-1 block w-full px-3 py-2 bg-slate-100 border border-slate-300 rounded-md shadow-sm cursor-not-allowed" />
                                        </div>
                                    )}
                                    <div>
                                        <label htmlFor="name" className="block text-sm font-medium text-slate-700">Full Name</label>
                                        <input type="text" id="name" value={name} onChange={(e) => setName(e.target.value)} required className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500" />
                                    </div>
                                    <div>
                                        <label htmlFor="phone" className="block text-sm font-medium text-slate-700">Phone Number</label>
                                        <input 
                                            type="tel" 
                                            id="phone" 
                                            value={phone} 
                                            onChange={(e) => setPhone(e.target.value)} 
                                            required 
                                            readOnly={!!user}
                                            className={`mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 ${!!user ? 'bg-slate-100 cursor-not-allowed' : ''}`}
                                        />
                                    </div>
                                    <div>
                                        <label htmlFor="coach" className="block text-sm font-medium text-slate-700">Coach (e.g., S6)</label>
                                        <input type="text" id="coach" value={coach} onChange={(e) => setCoach(e.target.value.toUpperCase())} required className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500" />
                                    </div>
                                    <div className="md:col-span-2">
                                        <label htmlFor="seat" className="block text-sm font-medium text-slate-700">Seat / Berth Number</label>
                                        <input type="text" id="seat" value={seat} onChange={(e) => setSeat(e.target.value)} required className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500" />
                                    </div>
                                </div>
                            </div>

                            <div>
                                <h2 className="text-2xl font-bold text-slate-800 border-b pb-4 mb-6">Payment Method</h2>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <PaymentOption 
                                        method="Online" 
                                        label="Pay Online"
                                        icon={<CreditCardIcon className="w-8 h-8"/>} 
                                        selected={paymentMethod === 'Online'} 
                                        onSelect={() => { setPaymentMethod('Online'); setError(''); }}
                                    />
                                    <PaymentOption 
                                        method="COD" 
                                        label="Cash on Delivery" 
                                        icon={<CashIcon className="w-8 h-8"/>} 
                                        selected={paymentMethod === 'COD'} 
                                        onSelect={() => { setPaymentMethod('COD'); setError(''); }}
                                    />
                                </div>
                                {error && <p className="text-red-500 text-sm mt-2 text-center">{error}</p>}
                            </div>

                        </div>

                        <div className="lg:col-span-1">
                            <div className="bg-white p-6 rounded-xl shadow-lg sticky top-24">
                                <h3 className="text-xl font-bold text-slate-800 border-b pb-3 mb-4">Order Summary</h3>
                                {restaurant && (
                                    <div className="pb-4 border-b mb-4">
                                        <p className="text-sm text-slate-500">Ordering from:</p>
                                        <p className="font-semibold text-slate-800">{restaurant.name}, {restaurant.station}</p>
                                    </div>
                                )}
                                <div className="space-y-3 max-h-48 overflow-y-auto pr-2">
                                    {cart.map(cartItem => (
                                        <div key={cartItem.item.id} className="flex justify-between items-center text-sm">
                                            <p className="text-slate-600">{cartItem.item.name} <span className="text-xs">x{cartItem.quantity}</span></p>
                                            <p className="font-medium text-slate-800">₹{cartItem.item.price * cartItem.quantity}</p>
                                        </div>
                                    ))}
                                </div>
                                <div className="border-t mt-4 pt-4 space-y-2">
                                    <div className="flex justify-between text-sm">
                                        <p className="text-slate-600">Subtotal</p>
                                        <p className="font-medium text-slate-800">₹{totalAmount}</p>
                                    </div>
                                    <div className="flex justify-between text-sm">
                                        <p className="text-slate-600">Platform & Delivery Fee</p>
                                        <p className="font-medium text-slate-800">₹{platformFee}</p>
                                    </div>
                                    <div className="flex justify-between font-bold text-lg mt-2 border-t pt-2">
                                        <p>Total</p>
                                        <p>₹{finalTotal}</p>
                                    </div>
                                </div>
                                 <div className="mt-6">
                                    <button type="submit" className="w-full bg-primary-600 text-white font-bold py-3 px-8 rounded-md hover:bg-primary-700 transition-colors duration-300 shadow-md">
                                        {paymentMethod === 'Online' ? `Proceed to Pay ₹${finalTotal}` : `Place Order (COD) - Pay ₹${finalTotal}`}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                 </form>
            </div>
        </div>
    );
};

export default CheckoutPage;