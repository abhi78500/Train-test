import React, { useState, useMemo } from 'react';
import { Restaurant } from '../types';
import MenuEditor from './MenuEditor';

interface MenuManagerProps {
    restaurants: Restaurant[];
    onSaveRestaurant: (restaurant: Restaurant) => void;
}

const MenuManager: React.FC<MenuManagerProps> = ({ restaurants, onSaveRestaurant }) => {
    const [selectedRestaurant, setSelectedRestaurant] = useState<Restaurant | null>(null);
    const [stationFilter, setStationFilter] = useState('All');

    const uniqueStations = useMemo(() => ['All', ...[...new Set(restaurants.map(r => r.station))].sort()], [restaurants]);

    const filteredRestaurants = useMemo(() => {
        if (stationFilter === 'All') {
            return restaurants;
        }
        return restaurants.filter(r => r.station === stationFilter);
    }, [restaurants, stationFilter]);
    
    const handleSelectRestaurant = (restaurant: Restaurant) => {
        setSelectedRestaurant(restaurant);
    };

    const handleSave = (updatedRestaurant: Restaurant) => {
        onSaveRestaurant(updatedRestaurant);
        // Update the selected restaurant in state to reflect changes instantly
        setSelectedRestaurant(updatedRestaurant);
    };

    return (
        <div className="bg-white rounded-lg shadow-md">
            <div className="p-4 border-b">
                <div className="flex items-center gap-2">
                     <label htmlFor="station-filter-menu" className="text-sm font-medium text-slate-700">Filter by Station:</label>
                     <select
                        id="station-filter-menu"
                        value={stationFilter}
                        onChange={(e) => {
                            setStationFilter(e.target.value);
                            setSelectedRestaurant(null); // Deselect restaurant when filter changes
                        }}
                        className="p-2 border-slate-300 rounded text-sm focus:ring-primary-500 focus:border-primary-500"
                    >
                        {uniqueStations.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 min-h-[60vh]">
                <div className="md:col-span-1 md:border-r overflow-y-auto max-h-[60vh]">
                    <ul className="divide-y">
                        {filteredRestaurants.map(r => (
                            <li key={r.id}>
                                <button 
                                    onClick={() => handleSelectRestaurant(r)}
                                    className={`w-full text-left p-4 hover:bg-primary-50 transition-colors ${selectedRestaurant?.id === r.id ? 'bg-primary-100' : ''}`}
                                >
                                    <p className="font-bold text-slate-800">{r.name}</p>
                                    <p className="text-sm text-slate-500">{r.station}</p>
                                </button>
                            </li>
                        ))}
                    </ul>
                </div>

                <div className="md:col-span-2 p-4 md:p-6 overflow-y-auto max-h-[60vh]">
                    {selectedRestaurant ? (
                        <MenuEditor restaurant={selectedRestaurant} onSave={handleSave} />
                    ) : (
                        <div className="flex items-center justify-center h-full text-slate-500">
                            <p className="text-lg">Select a restaurant to manage its menu.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default MenuManager;
