import React, { useState, useMemo } from 'react';
import { User, OrderDetails, OrderStatus, Agent, Restaurant } from '../../types';
import RestaurantFormModal from '../RestaurantFormModal';
import MenuManager from '../MenuManager';

interface AdminDashboardPageProps {
    user: User | null;
    orders: OrderDetails[];
    agents: Agent[];
    onUpdateStatus: (orderId: string, status: OrderStatus) => void;
    onAssignAgent: (orderId: string, agentId: number) => void;
    restaurants: Restaurant[];
    onSaveRestaurant: (restaurant: Restaurant) => void;
}

const statusOptions: OrderStatus[] = ['Pending', 'Accepted', 'Preparing', 'Out for Delivery', 'Delivered', 'Cancelled'];
const getStatusColor = (status: OrderStatus) => {
    switch (status) {
        case 'Pending': return 'bg-yellow-100 text-yellow-800';
        case 'Accepted': return 'bg-blue-100 text-blue-800';
        case 'Preparing': return 'bg-indigo-100 text-indigo-800';
        case 'Out for Delivery': return 'bg-purple-100 text-purple-800';
        case 'Delivered': return 'bg-green-100 text-green-800';
        case 'Cancelled': return 'bg-red-100 text-red-800';
        default: return 'bg-slate-100 text-slate-800';
    }
};

const OrderManager: React.FC<Pick<AdminDashboardPageProps, 'orders' | 'agents' | 'onUpdateStatus' | 'onAssignAgent'>> = ({ orders, agents, onUpdateStatus, onAssignAgent }) => {
    const [filterStatus, setFilterStatus] = useState<OrderStatus | 'All'>('All');

    const filteredOrders = useMemo(() => {
        if (filterStatus === 'All') {
            return orders;
        }
        return orders.filter(order => order.status === filterStatus);
    }, [orders, filterStatus]);

    return (
        <>
            <div className="bg-white p-4 rounded-lg shadow-md mb-6">
                <h3 className="font-bold text-lg mb-2">Filter Orders by Status</h3>
                <div className="flex flex-wrap gap-2">
                    {(['All', ...statusOptions] as const).map(status => (
                        <button
                            key={status}
                            onClick={() => setFilterStatus(status)}
                            className={`px-3 py-1 text-sm font-semibold rounded-full transition-colors ${
                                filterStatus === status ? 'bg-primary-600 text-white' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                            }`}
                        >
                            {status}
                        </button>
                    ))}
                </div>
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-x-auto">
                <table className="w-full text-sm text-left text-slate-500">
                    <thead className="text-xs text-slate-700 uppercase bg-slate-50">
                        <tr>
                            <th scope="col" className="px-6 py-3">Order ID</th>
                            <th scope="col" className="px-6 py-3">Restaurant</th>
                            <th scope="col" className="px-6 py-3">Customer</th>
                            <th scope="col" className="px-6 py-3">Total</th>
                            <th scope="col" className="px-6 py-3">Status</th>
                            <th scope="col" className="px-6 py-3">Agent</th>
                            <th scope="col" className="px-6 py-3 min-w-[200px]">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredOrders.length > 0 ? filteredOrders.map(order => (
                            <tr key={order.id} className="bg-white border-b hover:bg-slate-50">
                                <td className="px-6 py-4 font-mono font-medium text-slate-900">{order.id}</td>
                                <td className="px-6 py-4">{order.restaurantName}</td>
                                <td className="px-6 py-4">{order.name}<br/>({order.phone})</td>
                                <td className="px-6 py-4 font-semibold">₹{order.totalAmount}</td>
                                <td className="px-6 py-4">
                                    <span className={`px-2 py-1 text-xs font-bold rounded-full ${getStatusColor(order.status)}`}>
                                        {order.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4">
                                    {agents.find(a => a.id === order.agentId)?.name || 'Unassigned'}
                                </td>
                                <td className="px-6 py-4 flex flex-col gap-2">
                                    <select
                                        value={order.status}
                                        onChange={(e) => onUpdateStatus(order.id, e.target.value as OrderStatus)}
                                        className="w-full p-1 border-slate-300 rounded text-xs focus:ring-primary-500 focus:border-primary-500"
                                    >
                                        {statusOptions.map(s => <option key={s} value={s}>{s}</option>)}
                                    </select>
                                    <select
                                        value={order.agentId || ''}
                                        onChange={(e) => onAssignAgent(order.id, parseInt(e.target.value))}
                                        className="w-full p-1 border-slate-300 rounded text-xs disabled:bg-slate-100 disabled:cursor-not-allowed focus:ring-primary-500 focus:border-primary-500"
                                        disabled={order.status !== 'Accepted' && order.status !== 'Preparing'}
                                    >
                                        <option value="">Assign Agent</option>
                                        {agents.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                                    </select>
                                </td>
                            </tr>
                        )) : (
                            <tr>
                                <td colSpan={7} className="text-center py-8">No orders match the filter.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </>
    );
};

const RestaurantManager: React.FC<Pick<AdminDashboardPageProps, 'restaurants' | 'onSaveRestaurant'>> = ({ restaurants, onSaveRestaurant }) => {
    const [isModalOpen, setModalOpen] = useState(false);
    const [editingRestaurant, setEditingRestaurant] = useState<Restaurant | null>(null);
    const [stationFilter, setStationFilter] = useState('All');
    
    const uniqueStations = useMemo(() => ['All', ...[...new Set(restaurants.map(r => r.station))].sort()], [restaurants]);
    
    const filteredRestaurants = useMemo(() => {
        if (stationFilter === 'All') {
            return restaurants;
        }
        return restaurants.filter(r => r.station === stationFilter);
    }, [restaurants, stationFilter]);
    
    const handleAdd = () => {
        setEditingRestaurant(null);
        setModalOpen(true);
    };

    const handleEdit = (restaurant: Restaurant) => {
        setEditingRestaurant(restaurant);
        setModalOpen(true);
    };

    const handleSave = (restaurant: Restaurant) => {
        onSaveRestaurant(restaurant);
        setModalOpen(false);
    };

    return (
        <>
            <div className="bg-white p-4 rounded-lg shadow-md mb-6 flex flex-col sm:flex-row justify-between items-center gap-4">
                <div className="flex items-center gap-2">
                     <label htmlFor="station-filter" className="text-sm font-medium text-slate-700">Filter by Station:</label>
                     <select
                        id="station-filter"
                        value={stationFilter}
                        onChange={(e) => setStationFilter(e.target.value)}
                        className="p-2 border-slate-300 rounded text-sm focus:ring-primary-500 focus:border-primary-500"
                    >
                        {uniqueStations.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                </div>
                <button
                    onClick={handleAdd}
                    className="w-full sm:w-auto bg-primary-600 text-white font-bold py-2 px-4 rounded-md hover:bg-primary-700 transition-colors"
                >
                    + Add New Restaurant
                </button>
            </div>

            <div className="bg-white rounded-lg shadow-md overflow-x-auto">
                <table className="w-full text-sm text-left text-slate-500">
                    <thead className="text-xs text-slate-700 uppercase bg-slate-50">
                        <tr>
                            <th scope="col" className="px-6 py-3">ID</th>
                            <th scope="col" className="px-6 py-3">Name</th>
                            <th scope="col" className="px-6 py-3">Station</th>
                            <th scope="col" className="px-6 py-3">Cuisine</th>
                            <th scope="col" className="px-6 py-3">Rating</th>
                            <th scope="col" className="px-6 py-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                         {filteredRestaurants.length > 0 ? filteredRestaurants.map(r => (
                            <tr key={r.id} className="bg-white border-b hover:bg-slate-50">
                                <td className="px-6 py-4 font-medium text-slate-900">{r.id}</td>
                                <td className="px-6 py-4 font-semibold text-slate-800">{r.name}</td>
                                <td className="px-6 py-4">{r.station} ({r.stationCode})</td>
                                <td className="px-6 py-4">{r.cuisine}</td>
                                <td className="px-6 py-4">{r.rating} ★</td>
                                <td className="px-6 py-4">
                                    <div className="flex items-center gap-4">
                                        <button
                                            onClick={() => handleEdit(r)}
                                            className="font-medium text-primary-600 hover:text-primary-800"
                                        >
                                            Edit Details
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        )) : (
                            <tr>
                                <td colSpan={6} className="text-center py-8">No restaurants match the filter.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
            
            <RestaurantFormModal
                isOpen={isModalOpen}
                onClose={() => setModalOpen(false)}
                restaurant={editingRestaurant}
                onSave={handleSave}
            />
        </>
    );
};

const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ user, orders, agents, onUpdateStatus, onAssignAgent, restaurants, onSaveRestaurant }) => {
    const [activeTab, setActiveTab] = useState<'orders' | 'restaurants' | 'menu'>('orders');

    if (!user || user.role !== 'admin') {
        return <div className="p-8 text-center text-red-500">Access Denied. You must be an admin to view this page.</div>;
    }
    
    const tabStyle = "px-3 py-2 font-semibold text-sm rounded-t-lg border-b-2 transition-colors";
    const activeTabStyle = "text-primary-600 border-primary-600";
    const inactiveTabStyle = "text-slate-500 border-transparent hover:text-slate-700 hover:border-slate-300";

    return (
        <div className="bg-slate-100 min-h-screen p-4 sm:p-6 lg:p-8">
            <div className="max-w-7xl mx-auto">
                <header className="mb-8">
                    <h1 className="text-3xl font-extrabold text-slate-900">Admin Dashboard</h1>
                    <p className="text-slate-600 mt-1">Welcome, {user.name}. Manage orders and restaurants.</p>
                </header>

                <div className="mb-6 border-b border-slate-200">
                    <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                        <button
                            onClick={() => setActiveTab('orders')}
                            className={`${tabStyle} ${activeTab === 'orders' ? activeTabStyle : inactiveTabStyle}`}
                        >
                            Order Management
                        </button>
                        <button
                            onClick={() => setActiveTab('restaurants')}
                            className={`${tabStyle} ${activeTab === 'restaurants' ? activeTabStyle : inactiveTabStyle}`}
                        >
                            Restaurant Details
                        </button>
                        <button
                            onClick={() => setActiveTab('menu')}
                            className={`${tabStyle} ${activeTab === 'menu' ? activeTabStyle : inactiveTabStyle}`}
                        >
                            Menu Management
                        </button>
                    </nav>
                </div>

                {activeTab === 'orders' && (
                    <OrderManager orders={orders} agents={agents} onUpdateStatus={onUpdateStatus} onAssignAgent={onAssignAgent} />
                )}
                {activeTab === 'restaurants' && (
                    <RestaurantManager restaurants={restaurants} onSaveRestaurant={onSaveRestaurant} />
                )}
                 {activeTab === 'menu' && (
                    <MenuManager restaurants={restaurants} onSaveRestaurant={onSaveRestaurant} />
                )}
            </div>
        </div>
    );
};

export default AdminDashboardPage;