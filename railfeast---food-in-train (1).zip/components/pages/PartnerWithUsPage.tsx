import React, { useState } from 'react';
import { BuildingStorefrontIcon, CheckCircleIcon } from '../IconComponents';
import { PartnershipForm } from '../../types';
import { submitPartnershipForm } from '../../services/apiService';

const SuccessModal: React.FC<{ onClose: () => void }> = ({ onClose }) => (
    <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true">
        <div className="bg-white rounded-2xl shadow-xl w-full max-w-md transform transition-all text-center p-8">
            <CheckCircleIcon className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-slate-800">Submission Received!</h2>
            <p className="mt-2 text-slate-600">
                Thank you for your interest in partnering with RailFeast. Our vendor department will review your details and contact you soon.
            </p>
            <button
                onClick={onClose}
                className="mt-6 w-full sm:w-auto bg-primary-600 text-white font-bold py-2 px-8 rounded-md hover:bg-primary-700 transition-colors duration-300 shadow-md"
            >
                Close
            </button>
        </div>
    </div>
);

const FormField: React.FC<{ label: string; name: string; type?: string; placeholder: string; required?: boolean, error?: string, value: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void }> = 
    ({ label, name, type = 'text', placeholder, required, error, value, onChange }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-slate-700 mb-1">{label} {required && <span className="text-red-500">*</span>}</label>
        <input type={type} id={name} name={name} value={value} onChange={onChange} placeholder={placeholder} required={required}
            className={`block w-full px-3 py-2 bg-white border ${error ? 'border-red-500' : 'border-slate-300'} rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500`}
        />
        {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
    </div>
);

const RadioField: React.FC<{ label: string; name: 'hasGst' | 'hasFssai'; required?: boolean; error?: string; value: boolean | null; onChange: (name: 'hasGst' | 'hasFssai', value: boolean) => void }> = 
    ({ label, name, required, error, value, onChange }) => (
    <div>
        <label className="block text-sm font-medium text-slate-700 mb-1">{label} {required && <span className="text-red-500">*</span>}</label>
        <div className="flex gap-4 mt-2">
            <button type="button" onClick={() => onChange(name, true)} className={`flex-1 py-2 px-4 rounded-md border text-sm font-semibold transition-colors ${value === true ? 'bg-primary-600 text-white border-primary-600' : 'bg-white hover:bg-slate-50 border-slate-300'}`}>Yes</button>
            <button type="button" onClick={() => onChange(name, false)} className={`flex-1 py-2 px-4 rounded-md border text-sm font-semibold transition-colors ${value === false ? 'bg-primary-600 text-white border-primary-600' : 'bg-white hover:bg-slate-50 border-slate-300'}`}>No</button>
        </div>
            {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
    </div>
);

const PartnerWithUsPage: React.FC = () => {
    const [formData, setFormData] = useState<PartnershipForm>({
        stationName: '',
        restaurantName: '',
        restaurantMobile: '',
        ownerName: '',
        ownerMobile: '',
        email: '',
        distance: '',
        hasGst: null,
        hasFssai: null,
    });
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showSuccessModal, setShowSuccessModal] = useState(false);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleRadioChange = (name: 'hasGst' | 'hasFssai', value: boolean) => {
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const validate = (): boolean => {
        const newErrors: Record<string, string> = {};
        if (!formData.stationName.trim()) newErrors.stationName = "Station name is required.";
        if (!formData.restaurantName.trim()) newErrors.restaurantName = "Restaurant name is required.";
        if (!/^\d{10}$/.test(formData.restaurantMobile)) newErrors.restaurantMobile = "Enter a valid 10-digit mobile number.";
        if (!formData.ownerName.trim()) newErrors.ownerName = "Owner name is required.";
        if (!/^\d{10}$/.test(formData.ownerMobile)) newErrors.ownerMobile = "Enter a valid 10-digit mobile number.";
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) newErrors.email = "Enter a valid email address.";
        if (formData.hasGst === null) newErrors.hasGst = "Please select an option for GST.";
        if (formData.hasFssai === null) newErrors.hasFssai = "Please select an option for FSSAI.";
        
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!validate()) {
            return;
        }

        setIsSubmitting(true);
        try {
            await submitPartnershipForm(formData);
            setShowSuccessModal(true);
            // Reset form
            setFormData({
                stationName: '', restaurantName: '', restaurantMobile: '',
                ownerName: '', ownerMobile: '', email: '',
                distance: '', hasGst: null, hasFssai: null,
            });
        } catch(error) {
            console.error("Submission failed", error);
            alert("There was an error submitting your application. Please try again.");
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="bg-slate-50 py-12 sm:py-16">
            {showSuccessModal && <SuccessModal onClose={() => setShowSuccessModal(false)} />}
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
                <header className="text-center mb-12">
                    <BuildingStorefrontIcon className="w-16 h-16 text-primary-600 mx-auto mb-4" />
                    <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight">Partner with RailFeast</h1>
                    <p className="mt-4 text-xl text-slate-600">Join our network of trusted restaurants and serve thousands of train passengers daily.</p>
                </header>
                
                <form onSubmit={handleSubmit} className="bg-white p-8 rounded-xl shadow-lg space-y-6" noValidate>
                    <FormField label="Serviceable Station Name" name="stationName" placeholder="e.g., New Delhi (NDLS)" required error={errors.stationName} value={formData.stationName} onChange={handleInputChange}/>
                    <FormField label="Restaurant Name" name="restaurantName" placeholder="Your restaurant's official name" required error={errors.restaurantName} value={formData.restaurantName} onChange={handleInputChange}/>
                    <FormField label="Restaurant Mobile Number" name="restaurantMobile" type="tel" placeholder="10-digit contact number for orders" required error={errors.restaurantMobile} value={formData.restaurantMobile} onChange={handleInputChange}/>
                    <FormField label="Owner Name" name="ownerName" placeholder="Full name of the owner" required error={errors.ownerName} value={formData.ownerName} onChange={handleInputChange}/>
                    <FormField label="Owner Mobile Number" name="ownerMobile" type="tel" placeholder="10-digit personal contact number" required error={errors.ownerMobile} value={formData.ownerMobile} onChange={handleInputChange}/>
                    <FormField label="Owner Email ID" name="email" type="email" placeholder="your.email@example.com" required error={errors.email} value={formData.email} onChange={handleInputChange}/>
                    <FormField label="Distance from Railway Station (in KM)" name="distance" type="number" placeholder="e.g., 1.5" value={formData.distance} onChange={handleInputChange}/>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <RadioField label="GST Available?" name="hasGst" required error={errors.hasGst} value={formData.hasGst} onChange={handleRadioChange} />
                        <RadioField label="FSSAI Available?" name="hasFssai" required error={errors.hasFssai} value={formData.hasFssai} onChange={handleRadioChange} />
                    </div>

                    <div className="pt-4">
                        <button type="submit" disabled={isSubmitting} className="w-full bg-primary-600 text-white font-bold py-3 px-8 rounded-md hover:bg-primary-700 transition-colors duration-300 shadow-md disabled:bg-primary-400 disabled:cursor-not-allowed flex items-center justify-center">
                            {isSubmitting ? (
                                <>
                                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                    </svg>
                                    Submitting...
                                </>
                            ) : 'Submit Application'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default PartnerWithUsPage;
