import React from 'react';
import { Restaurant } from '../types';
import { StarIcon } from './IconComponents';

interface RestaurantCardProps {
    restaurant: Restaurant;
    onClick: () => void;
}

const RestaurantCard: React.FC<RestaurantCardProps> = ({ restaurant, onClick }) => {
    return (
        <div onClick={onClick} className="bg-white rounded-lg shadow-lg overflow-hidden cursor-pointer transform hover:-translate-y-2 transition-transform duration-300">
            <img src={restaurant.image} alt={restaurant.name} className="w-full h-48 object-cover" />
            <div className="p-6">
                <h3 className="text-xl font-bold text-slate-800">{restaurant.name}</h3>
                <p className="text-slate-500 text-sm mt-1">At {restaurant.station}</p>
                <div className="flex items-center justify-between mt-4">
                    <div className="flex items-center gap-1">
                        <StarIcon className="w-5 h-5 text-amber-400" />
                        <span className="font-bold text-slate-700">{restaurant.rating}</span>
                    </div>
                    <span className="text-sm font-medium text-primary-600">{restaurant.cuisine}</span>
                </div>
            </div>
        </div>
    );
};

export default RestaurantCard;