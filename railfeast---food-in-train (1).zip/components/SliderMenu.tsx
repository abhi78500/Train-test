import React from 'react';
import { XMarkIcon, UserIcon, DashboardIcon } from './IconComponents';
import { User, OrderDetails } from '../types';

interface SliderMenuProps {
    isOpen: boolean;
    onClose: () => void;
    user: User | null;
    onLoginClick: () => void;
    onLogout: () => void;
    activeOrder: OrderDetails | null;
    onTrackOrderClick: () => void;
    onOrderHistoryClick: () => void;
    onAboutUsClick: () => void;
    onPrivacyPolicyClick: () => void;
    onTermsClick: () => void;
    onPartnerWithUsClick: () => void;
    onDashboardClick: () => void;
}

const menuItems = [
    { name: 'Track Order', href: '#', id: 'track-order' },
    { name: 'Order History', href: '#', id: 'order-history' },
    { name: 'Partner with Us', href: '#', id: 'partner-with-us' },
    { name: 'About Us', href: '#', id: 'about-us' },
    { name: 'Terms & Conditions', href: '#', id: 'terms' },
    { name: 'Privacy Policy', href: '#', id: 'privacy' },
];

export const SliderMenu: React.FC<SliderMenuProps> = ({ 
    isOpen, 
    onClose, 
    user, 
    onLoginClick, 
    onLogout, 
    activeOrder, 
    onTrackOrderClick, 
    onOrderHistoryClick, 
    onAboutUsClick, 
    onPrivacyPolicyClick,
    onTermsClick,
    onPartnerWithUsClick,
    onDashboardClick
}) => {
    const hasActiveOrder = !!activeOrder;
    
    const handleItemClick = (id: string) => {
        onClose();
        switch (id) {
            case 'track-order':
                onTrackOrderClick();
                break;
            case 'order-history':
                if (user) onOrderHistoryClick();
                break;
            case 'about-us':
                onAboutUsClick();
                break;
            case 'privacy':
                onPrivacyPolicyClick();
                break;
            case 'terms':
                onTermsClick();
                break;
            case 'partner-with-us':
                onPartnerWithUsClick();
                break;
            default:
                break;
        }
    };

    return (
        <>
            {/* Overlay */}
            <div
                className={`fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm z-40 transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
                onClick={onClose}
                aria-hidden="true"
            />

            {/* Slider Panel */}
            <div
                className={`fixed top-0 left-0 h-full w-80 max-w-[80vw] bg-white shadow-xl z-50 transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
                role="dialog"
                aria-modal="true"
                aria-labelledby="menu-title"
            >
                <div className="flex flex-col h-full">
                    {/* Header */}
                    <div className="flex items-center justify-between p-4 border-b">
                        <h2 id="menu-title" className="text-xl font-bold text-primary-700">Menu</h2>
                        <button onClick={onClose} className="p-1 rounded-full text-slate-500 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-primary-500">
                            <span className="sr-only">Close menu</span>
                            <XMarkIcon className="w-6 h-6" />
                        </button>
                    </div>

                    {/* User Profile / Login */}
                    <div className="p-4 border-b">
                        {user ? (
                            <div className="flex items-center gap-4">
                                <UserIcon className="w-10 h-10 text-slate-500"/>
                                <div>
                                    <p className="font-semibold text-slate-800">{user.name || 'Logged In'}</p>
                                    <p className="text-sm text-slate-600">{user.mobile}</p>
                                    <p className="text-xs text-primary-700 font-semibold capitalize">{user.role}</p>
                                </div>
                            </div>
                        ) : (
                             <button
                                onClick={onLoginClick}
                                className="w-full bg-primary-600 text-white font-bold py-3 px-6 rounded-md hover:bg-primary-700 transition-colors duration-300 shadow-sm"
                            >
                                Login / Sign Up
                            </button>
                        )}
                    </div>


                    {/* Menu Items */}
                    <nav className="flex-grow p-4">
                        <ul className="space-y-2">
                           {user && user.role !== 'customer' && (
                                <li>
                                    <button
                                        onClick={onDashboardClick}
                                        className="w-full text-left flex items-center gap-3 px-4 py-3 rounded-md font-medium text-white bg-primary-600 hover:bg-primary-700"
                                    >
                                        <DashboardIcon className="w-6 h-6"/>
                                        <span>Go to Dashboard</span>
                                    </button>
                                </li>
                           )}
                           {menuItems.map((item) => {
                                const isTrackOrder = item.id === 'track-order';
                                const isOrderHistory = item.id === 'order-history';
                                
                                const isTrackDisabled = isTrackOrder && !hasActiveOrder && (!user || (user && user.role === 'customer' && !onOrderHistoryClick));
                                const isHistoryDisabled = isOrderHistory && !user;
                                const isDisabled = isTrackDisabled || isHistoryDisabled;

                                return (
                                <li key={item.id}>
                                    <button
                                        onClick={() => handleItemClick(item.id)}
                                        disabled={isDisabled}
                                        className={`w-full text-left flex items-center justify-between px-4 py-3 rounded-md font-medium transition-colors ${
                                            isDisabled
                                                ? 'text-slate-400 cursor-not-allowed'
                                                : 'text-slate-700 hover:bg-primary-50 hover:text-primary-700'
                                        }`}
                                    >
                                        <div className="flex flex-col">
                                            <span>{item.name}</span>
                                            {isTrackOrder && hasActiveOrder && activeOrder.id && (
                                                <span className="text-xs font-mono text-primary-600">{activeOrder.id}</span>
                                            )}
                                        </div>
                                        {isTrackOrder && hasActiveOrder && (
                                            <span className="relative flex h-2.5 w-2.5">
                                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary-400 opacity-75"></span>
                                                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-primary-500"></span>
                                            </span>
                                        )}
                                    </button>
                                </li>
                            )})}
                        </ul>
                    </nav>

                     {/* Footer / Logout */}
                     <div className="p-4 border-t text-xs text-slate-400">
                        {user && (
                            <button onClick={onLogout} className="w-full text-left mb-4 px-4 py-3 rounded-md text-red-600 font-medium hover:bg-red-50 transition-colors">
                                Logout
                            </button>
                        )}
                        RailFeast &copy; {new Date().getFullYear()}
                    </div>
                </div>
            </div>
        </>
    );
};