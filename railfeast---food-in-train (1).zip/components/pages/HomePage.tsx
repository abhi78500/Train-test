import React, { useState } from 'react';
import { Restaurant } from '../../types';
import RestaurantCard from '../RestaurantCard';

interface HomePageProps {
    onSearch: (value: string, type: 'pnr' | 'train') => void;
    onSelectRestaurant: (restaurant: Restaurant) => void;
    restaurants: Restaurant[];
    isLoading: boolean;
}

const SearchForm: React.FC<{ onSearch: (value: string, type: 'pnr' | 'train') => void, isLoading: boolean }> = ({ onSearch, isLoading }) => {
    const [searchType, setSearchType] = useState<'pnr' | 'train'>('pnr');
    const [value, setValue] = useState('');

    const isPnr = searchType === 'pnr';

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const trimmedValue = value.trim();
        const isValidPnr = isPnr && trimmedValue.length === 10 && /^\d+$/.test(trimmedValue);
        const isValidTrainNo = !isPnr && trimmedValue.length > 0 && trimmedValue.length <= 5 && /^\d+$/.test(trimmedValue);

        if (isValidPnr || isValidTrainNo) {
            onSearch(trimmedValue, searchType);
        } else {
            alert(`Please enter a valid ${isPnr ? '10-digit PNR number' : '5-digit Train number'}.`);
        }
    };
    
    const handleTypeChange = (type: 'pnr' | 'train') => {
        setSearchType(type);
        setValue('');
    };

    return (
        <div className="mt-8 bg-white p-4 rounded-lg shadow-lg w-full max-w-2xl mx-auto">
             <div className="flex border-b">
                <button 
                    onClick={() => handleTypeChange('pnr')}
                    className={`flex-1 py-2 text-center font-semibold rounded-t-md transition-colors ${isPnr ? 'bg-primary-50 text-primary-700 border-b-2 border-primary-500' : 'text-slate-500 hover:bg-slate-100'}`}
                    aria-pressed={isPnr}
                >
                    Search by PNR
                </button>
                <button 
                    onClick={() => handleTypeChange('train')}
                    className={`flex-1 py-2 text-center font-semibold rounded-t-md transition-colors ${!isPnr ? 'bg-primary-50 text-primary-700 border-b-2 border-primary-500' : 'text-slate-500 hover:bg-slate-100'}`}
                    aria-pressed={!isPnr}
                >
                    Search by Train No.
                </button>
            </div>
            <form onSubmit={handleSubmit} className="mt-4 flex flex-col sm:flex-row items-center gap-2">
                <input
                    type="text"
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                    placeholder={isPnr ? "Enter 10-digit PNR Number" : "Enter 5-digit Train Number"}
                    maxLength={isPnr ? 10 : 5}
                    className="w-full sm:flex-grow px-4 py-3 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                    aria-label={isPnr ? "PNR Number" : "Train Number"}
                />
                <button 
                    type="submit" 
                    disabled={isLoading} 
                    className="w-full sm:w-auto bg-primary-600 text-white font-bold py-3 px-8 rounded-md hover:bg-primary-700 transition-colors duration-300 shadow-md flex items-center justify-center disabled:bg-primary-400 disabled:cursor-wait"
                >
                    {isLoading ? (
                         <>
                            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Searching...
                        </>
                    ) : (
                        'Find Food'
                    )}
                </button>
            </form>
        </div>
    );
};

const HowItWorks: React.FC = () => {
    const steps = [
        { title: "Enter PNR / Train No.", description: "Provide your journey details to see restaurants serving your route." },
        { title: "Choose Your Meal", description: "Browse menus from top-rated restaurants at upcoming stations." },
        { title: "Confirm & Pay", description: "Pay securely online. COD is also available at select restaurants." },
        { title: "Enjoy at Your Seat", description: "Your fresh, hot meal will be delivered right to your seat." }
    ];
    return (
        <div className="bg-white py-16 sm:py-24">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <h2 className="text-3xl font-bold tracking-tight text-center text-slate-900 mb-12">How It Works</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    {steps.map((step, index) => (
                        <div key={index} className="text-center p-6 bg-slate-50 rounded-lg">
                            <div className="flex items-center justify-center h-12 w-12 rounded-full bg-primary-500 text-white font-bold text-xl mx-auto mb-4">{index + 1}</div>
                            <h3 className="text-lg font-semibold text-slate-800 mb-2">{step.title}</h3>
                            <p className="text-slate-600">{step.description}</p>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

const FeaturedRestaurants: React.FC<{ restaurants: Restaurant[], onSelectRestaurant: (restaurant: Restaurant) => void }> = ({ restaurants, onSelectRestaurant }) => (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
        <h2 className="text-3xl font-bold tracking-tight text-center text-slate-900 mb-12">Browse Partner Restaurants</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {restaurants.slice(0, 3).map(restaurant => (
                <RestaurantCard 
                    key={restaurant.id}
                    restaurant={restaurant}
                    onClick={() => onSelectRestaurant(restaurant)}
                />
            ))}
        </div>
    </div>
);


const HomePage: React.FC<HomePageProps> = ({ onSearch, onSelectRestaurant, restaurants, isLoading }) => {
    return (
        <>
            <div className="relative bg-primary-800 text-white py-20 sm:py-32 overflow-hidden">
                <div className="absolute inset-0">
                    <img src="https://picsum.photos/seed/trainview/1920/1080" alt="Train window view" className="w-full h-full object-cover opacity-30" />
                </div>
                <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 text-center">
                    <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight">
                        Pure Veg & Jain Food,
                        <br />
                        Delivered Right to Your Seat.
                    </h1>
                    <p className="mt-6 max-w-2xl mx-auto text-lg text-primary-200">
                        Never compromise on your meals during a train journey again. Order pure vegetarian and Jain food from trusted restaurants and get it delivered on time.
                    </p>
                    <SearchForm onSearch={onSearch} isLoading={isLoading} />
                </div>
            </div>
            <HowItWorks />
            <FeaturedRestaurants restaurants={restaurants} onSelectRestaurant={onSelectRestaurant} />
        </>
    );
};

export default HomePage;
