

import React from 'react';
import { Restaurant, StationInfo } from '../../types';
import RestaurantCard from '../RestaurantCard';

interface RestaurantsListPageProps {
    station: StationInfo;
    restaurants: Restaurant[];
    onSelectRestaurant: (restaurant: Restaurant) => void;
    isLoading: boolean;
}

const RestaurantSkeleton: React.FC = () => (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="w-full h-48 bg-slate-200"></div>
        <div className="p-6">
            <div className="h-6 bg-slate-200 rounded w-3/4 mb-2"></div>
            <div className="h-4 bg-slate-200 rounded w-1/2"></div>
            <div className="flex items-center justify-between mt-4">
                <div className="h-6 w-12 bg-slate-200 rounded"></div>
                <div className="h-4 w-24 bg-slate-200 rounded"></div>
            </div>
        </div>
    </div>
);

const RestaurantsListPage: React.FC<RestaurantsListPageProps> = ({ station, restaurants, onSelectRestaurant, isLoading }) => {
    return (
         <div className="bg-white py-12 sm:py-16">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                    <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900">Restaurants at {station.name}</h1>
                    <p className="mt-3 text-lg text-slate-600">
                       Choose a restaurant to see the menu. Food will be delivered at {station.name} ({station.code}).
                    </p>
                </div>

                {isLoading ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto animate-pulse">
                        {[...Array(3)].map((_, i) => <RestaurantSkeleton key={i} />)}
                    </div>
                ) : restaurants.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
                        {restaurants.map(restaurant => (
                            <RestaurantCard
                                key={restaurant.id}
                                restaurant={restaurant}
                                onClick={() => onSelectRestaurant(restaurant)}
                            />
                        ))}
                    </div>
                ) : (
                    <div className="text-center text-slate-500 py-16">
                        <p className="text-xl font-semibold">No partner restaurants found for this station.</p>
                        <p className="mt-2">We are working on expanding our services. Please check back later.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default RestaurantsListPage;
