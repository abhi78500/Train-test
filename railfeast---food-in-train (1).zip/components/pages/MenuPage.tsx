import React, { useState, useMemo, useCallback } from 'react';
import { Restaurant, MenuItem, CartItem } from '../../types';
import { StarIcon, JainIcon, NonVegIcon, SparklesIcon } from '../IconComponents';
import { getMealRecommendations } from '../../services/geminiService';

interface MenuPageProps {
    restaurant: Restaurant;
    cart: CartItem[];
    updateCart: (item: CartItem, quantity: number) => void;
    onProceedToCheckout: () => void;
}

const AIRecommender: React.FC<{ restaurant: Restaurant }> = ({ restaurant }) => {
    const [recommendation, setRecommendation] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const fetchRecommendations = useCallback(async () => {
        setIsLoading(true);
        setError('');
        setRecommendation('');
        try {
            const result = await getMealRecommendations(restaurant.name, restaurant.station, restaurant.menu);
            setRecommendation(result);
        } catch (err) {
            console.error(err);
            setError('Could not fetch recommendations. Please try again.');
        } finally {
            setIsLoading(false);
        }
    }, [restaurant]);

    return (
        <div className="bg-primary-50 border-2 border-primary-200 rounded-lg p-6 my-8">
            <div className="flex flex-col sm:flex-row items-center gap-4">
                <SparklesIcon className="w-12 h-12 text-primary-500 shrink-0" />
                <div className="flex-grow text-center sm:text-left">
                    <h3 className="text-xl font-bold text-primary-800">Don't know what to order?</h3>
                    <p className="text-primary-700 mt-1">Let our AI suggest a perfect sattvic meal for you!</p>
                </div>
                <button
                    onClick={fetchRecommendations}
                    disabled={isLoading}
                    className="w-full sm:w-auto shrink-0 px-6 py-2 bg-primary-600 text-white font-semibold rounded-lg hover:bg-primary-700 disabled:bg-primary-400 disabled:cursor-not-allowed transition-colors"
                >
                    {isLoading ? 'Thinking...' : 'Ask AI'}
                </button>
            </div>
            {error && <p className="mt-4 text-center text-red-600">{error}</p>}
            {recommendation && (
                <div className="mt-4 p-4 bg-white rounded-md border border-primary-200">
                    <p className="text-slate-700 whitespace-pre-wrap font-serif">{recommendation}</p>
                </div>
            )}
        </div>
    );
};

const MenuItemCard: React.FC<{ item: MenuItem; quantity: number; onQuantityChange: (newQuantity: number) => void; }> = ({ item, quantity, onQuantityChange }) => {
    return (
        <div className="flex items-start gap-4 p-4 border-b border-slate-200">
            {item.veg ? <JainIcon className="w-5 h-5 mt-1 shrink-0 text-green-600"/> : <NonVegIcon className="w-5 h-5 mt-1 shrink-0 text-red-600" />}
            <div className="flex-grow">
                <h4 className="font-bold text-lg text-slate-800">{item.name}</h4>
                <p className="text-slate-600 text-sm mt-1">{item.description}</p>
                <p className="font-semibold text-slate-800 mt-2">₹{item.price}</p>
            </div>
            <div className="shrink-0 flex items-center justify-end w-28">
                {quantity > 0 ? (
                    <div className="flex items-center gap-2 border border-primary-500 rounded-md">
                        <button onClick={() => onQuantityChange(quantity - 1)} className="px-2 py-1 text-primary-600 font-bold">-</button>
                        <span className="px-2 font-medium">{quantity}</span>
                        <button onClick={() => onQuantityChange(quantity + 1)} className="px-2 py-1 text-primary-600 font-bold">+</button>
                    </div>
                ) : (
                    <button onClick={() => onQuantityChange(1)} className="px-4 py-1.5 bg-primary-100 text-primary-700 font-semibold border border-primary-300 rounded-md hover:bg-primary-200 transition-colors">
                        ADD
                    </button>
                )}
            </div>
        </div>
    );
};

const MenuPage: React.FC<MenuPageProps> = ({ restaurant, cart, updateCart, onProceedToCheckout }) => {
    const totalAmount = useMemo(() => cart.reduce((sum, cartItem) => sum + cartItem.item.price * cartItem.quantity, 0), [cart]);

    const handleQuantityChange = (item: MenuItem, newQuantity: number) => {
        updateCart({ item, quantity: newQuantity }, newQuantity);
    };
    
    return (
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="bg-white rounded-xl shadow-xl overflow-hidden">
                <div className="p-6 md:p-8">
                    <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900">{restaurant.name}</h1>
                    <p className="text-slate-600 mt-2">Delivery at {restaurant.station}</p>
                    <div className="flex items-center gap-4 mt-2 text-sm">
                        <div className="flex items-center gap-1">
                            <StarIcon className="w-5 h-5 text-amber-400" />
                            <span className="font-bold text-slate-700">{restaurant.rating}</span>
                        </div>
                        <span className="text-slate-500">•</span>
                        <span className="font-medium text-slate-700">{restaurant.cuisine}</span>
                         <span className="text-slate-500">•</span>
                        <span className="font-medium text-slate-700">{restaurant.deliveryTime}</span>
                    </div>
                </div>

                <AIRecommender restaurant={restaurant} />
                
                <div className="p-2 md:p-4">
                     <h2 className="text-2xl font-bold text-slate-800 px-4 pb-2">Menu</h2>
                    {restaurant.menu.map(item => {
                        const cartItem = cart.find(ci => ci.item.id === item.id);
                        return (
                            <MenuItemCard
                                key={item.id}
                                item={item}
                                quantity={cartItem ? cartItem.quantity : 0}
                                onQuantityChange={(newQuantity) => handleQuantityChange(item, newQuantity)}
                            />
                        );
                    })}
                </div>
            </div>

            {cart.length > 0 && (
                <div className="sticky bottom-4 mt-8">
                    <div className="container mx-auto max-w-3xl">
                        <div className="bg-primary-700 text-white rounded-lg shadow-2xl p-4 flex justify-between items-center">
                            <div>
                                <p className="font-bold text-lg">{cart.length} item{cart.length > 1 ? 's' : ''} in cart</p>
                                <p className="text-primary-200">Total: ₹{totalAmount}</p>
                            </div>
                            <button onClick={onProceedToCheckout} className="bg-white text-primary-700 font-bold py-2 px-6 rounded-md hover:bg-primary-100 transition-colors">
                                Proceed to Checkout
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default MenuPage;