import React, { useState, useEffect } from 'react';
import { CreditCardIcon, CheckCircleIcon } from './IconComponents';

interface PaymentGatewayModalProps {
    isOpen: boolean;
    onClose: () => void;
    onPaymentSuccess: () => void;
    amount: number;
}

const PaymentGatewayModal: React.FC<PaymentGatewayModalProps> = ({ isOpen, onClose, onPaymentSuccess, amount }) => {
    const [isProcessing, setIsProcessing] = useState(false);
    const [isPaid, setIsPaid] = useState(false);

    useEffect(() => {
        if (!isOpen) {
            // Reset state when modal is closed
            setTimeout(() => {
                setIsProcessing(false);
                setIsPaid(false);
            }, 300); // allow for closing animation
        }
    }, [isOpen]);

    const handlePayment = () => {
        setIsProcessing(true);
        setTimeout(() => {
            setIsPaid(true);
            setIsProcessing(false);
            setTimeout(() => {
                onPaymentSuccess();
            }, 1500); // wait a moment on success screen
        }, 2000); // simulate 2s processing time
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-labelledby="payment-title">
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm transform transition-all" onClick={(e) => e.stopPropagation()}>
                <div className="p-6 sm:p-8 text-center">
                    {!isPaid ? (
                        <>
                            <CreditCardIcon className="h-12 w-12 text-primary-600 mx-auto mb-4" />
                            <h2 id="payment-title" className="text-2xl font-bold text-slate-800">
                                Secure Payment
                            </h2>
                            <p className="mt-2 text-slate-600">
                                You are about to pay
                            </p>
                            <p className="text-4xl font-extrabold text-slate-900 my-4">
                                ₹{amount.toFixed(2)}
                            </p>
                             <div className="bg-slate-50 p-4 rounded-lg text-sm text-slate-500 border">
                                This is a simulated payment gateway. No real transaction will be made.
                            </div>
                            <div className="mt-6 space-y-3">
                                <button
                                    onClick={handlePayment}
                                    disabled={isProcessing}
                                    className="w-full bg-primary-600 text-white font-bold py-3 px-8 rounded-md hover:bg-primary-700 transition-colors duration-300 shadow-md disabled:bg-primary-400 disabled:cursor-wait flex items-center justify-center"
                                >
                                    {isProcessing ? (
                                        <>
                                            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                            </svg>
                                            Processing...
                                        </>
                                    ) : (
                                        `Pay Now`
                                    )}
                                </button>
                                <button
                                    onClick={onClose}
                                    disabled={isProcessing}
                                    className="w-full font-semibold text-slate-600 py-2 rounded-md hover:bg-slate-100 transition-colors"
                                >
                                    Cancel Payment
                                </button>
                            </div>
                        </>
                    ) : (
                        <div className="flex flex-col items-center justify-center">
                             <CheckCircleIcon className="w-20 h-20 text-green-500 mx-auto mb-4" />
                            <h2 className="text-2xl font-bold text-slate-800">Payment Successful!</h2>
                             <p className="mt-2 text-slate-600">
                                Your order is being placed. Please wait...
                            </p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default PaymentGatewayModal;
