
import React, { useState, useMemo } from 'react';
import { User, OrderDetails, OrderStatus } from '../../types';

interface VendorDashboardPageProps {
    user: User | null;
    orders: OrderDetails[];
    onUpdateStatus: (orderId: string, status: OrderStatus) => void;
}

const getStatusColor = (status: OrderStatus) => {
    switch (status) {
        case 'Pending': return 'bg-yellow-100 text-yellow-800';
        case 'Accepted': return 'bg-blue-100 text-blue-800';
        case 'Preparing': return 'bg-indigo-100 text-indigo-800';
        case 'Out for Delivery': return 'bg-purple-100 text-purple-800';
        case 'Delivered': return 'bg-green-100 text-green-800';
        case 'Cancelled': return 'bg-red-100 text-red-800';
        default: return 'bg-slate-100 text-slate-800';
    }
};

const VendorDashboardPage: React.FC<VendorDashboardPageProps> = ({ user, orders, onUpdateStatus }) => {
    
    const restaurantOrders = useMemo(() => {
        return orders
            .filter(order => order.restaurantId === user?.restaurantId)
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [orders, user]);

    if (!user || user.role !== 'vendor' || !user.restaurantId) {
        return <div className="p-8 text-center text-red-500">Access Denied. You must be a vendor to view this page.</div>;
    }

    const newOrders = restaurantOrders.filter(o => o.status === 'Pending');
    const activeOrders = restaurantOrders.filter(o => ['Accepted', 'Preparing'].includes(o.status));
    const completedOrders = restaurantOrders.filter(o => ['Out for Delivery', 'Delivered', 'Cancelled'].includes(o.status));

    const renderOrderCard = (order: OrderDetails) => (
        <div key={order.id} className="bg-white rounded-lg shadow-md p-4 flex flex-col gap-3">
            <div className="flex justify-between items-start">
                <div>
                    <p className="font-bold text-slate-800">{order.id}</p>
                    <p className="text-xs text-slate-500">{new Date(order.date).toLocaleString()}</p>
                </div>
                <span className={`px-2 py-1 text-xs font-bold rounded-full ${getStatusColor(order.status)}`}>
                    {order.status}
                </span>
            </div>
            <div className="border-t border-b py-2 space-y-1">
                {order.cart.map(item => (
                    <div key={item.item.id} className="flex justify-between text-sm">
                        <p>{item.item.name}</p>
                        <p className="font-semibold">x {item.quantity}</p>
                    </div>
                ))}
            </div>
             <div className="flex justify-between items-center text-sm font-semibold">
                <p>Total:</p>
                <p>₹{order.totalAmount}</p>
            </div>
            {order.status === 'Pending' && (
                <div className="flex gap-2 mt-2">
                    <button 
                        onClick={() => onUpdateStatus(order.id, 'Accepted')}
                        className="flex-1 bg-green-500 text-white text-sm font-bold py-2 rounded hover:bg-green-600"
                    >
                        Accept
                    </button>
                    <button 
                        onClick={() => onUpdateStatus(order.id, 'Cancelled')}
                        className="flex-1 bg-red-500 text-white text-sm font-bold py-2 rounded hover:bg-red-600"
                    >
                        Decline
                    </button>
                </div>
            )}
            {order.status === 'Accepted' && (
                <button 
                    onClick={() => onUpdateStatus(order.id, 'Preparing')}
                    className="w-full bg-blue-500 text-white text-sm font-bold py-2 rounded hover:bg-blue-600 mt-2"
                >
                    Mark as Preparing
                </button>
            )}
        </div>
    );

    return (
        <div className="bg-slate-100 min-h-screen p-4 sm:p-6 lg:p-8">
            <div className="max-w-7xl mx-auto">
                <header className="mb-8">
                    <h1 className="text-3xl font-extrabold text-slate-900">Vendor Dashboard</h1>
                    <p className="text-slate-600 mt-1">Managing orders for your restaurant.</p>
                </header>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {/* New Orders */}
                    <div className="space-y-4">
                        <h2 className="text-xl font-bold text-slate-800 border-b-2 border-yellow-400 pb-2">New Orders ({newOrders.length})</h2>
                        <div className="space-y-4 max-h-[70vh] overflow-y-auto p-1">
                             {newOrders.length > 0 ? newOrders.map(renderOrderCard) : <p className="text-slate-500 text-center py-4">No new orders.</p>}
                        </div>
                    </div>
                    {/* Active Orders */}
                    <div className="space-y-4">
                        <h2 className="text-xl font-bold text-slate-800 border-b-2 border-blue-400 pb-2">In Progress ({activeOrders.length})</h2>
                         <div className="space-y-4 max-h-[70vh] overflow-y-auto p-1">
                            {activeOrders.length > 0 ? activeOrders.map(renderOrderCard) : <p className="text-slate-500 text-center py-4">No active orders.</p>}
                        </div>
                    </div>
                    {/* Completed Orders */}
                    <div className="space-y-4">
                        <h2 className="text-xl font-bold text-slate-800 border-b-2 border-green-400 pb-2">Completed & Past ({completedOrders.length})</h2>
                         <div className="space-y-4 max-h-[70vh] overflow-y-auto p-1">
                            {completedOrders.length > 0 ? completedOrders.map(renderOrderCard) : <p className="text-slate-500 text-center py-4">No completed orders.</p>}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default VendorDashboardPage;
