import React from 'react';

const TermsAndConditionsPage: React.FC = () => {
    
    const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
        <section className="mb-8">
            <h2 className="text-2xl font-bold text-slate-800 mb-3 border-b pb-2">{title}</h2>
            <div className="space-y-4">{children}</div>
        </section>
    );

    return (
        <div className="bg-slate-50 py-12 sm:py-16">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl bg-white p-8 sm:p-12 rounded-lg shadow-lg">
                <header className="text-center mb-10">
                    <h1 className="text-4xl font-extrabold text-slate-900">Terms & Conditions</h1>
                    <p className="mt-2 text-slate-500">Last updated: {new Date().toLocaleDateString()}</p>
                </header>

                <article className="text-slate-700 leading-relaxed">
                    <p className="mb-8">
                        Please read these Terms and Conditions ("Terms") carefully before using the RailFeast service. Your access to and use of the Service is conditioned on your acceptance of and compliance with these Terms. These Terms apply to all visitors and users who access or use the Service.
                    </p>

                    <Section title="1. Placing an Order">
                        <p>
                            By placing an order through RailFeast, you warrant that you are legally capable of entering into binding contracts and that the information you provide is accurate and complete.
                        </p>
                        <ul className="list-disc list-inside space-y-2 pl-4">
                            <li><strong>Accuracy of Information:</strong> You are responsible for providing an accurate PNR or train number, delivery station, contact number, coach, and seat number. RailFeast is not liable for non-delivery or incorrect delivery due to inaccurate information provided by you.</li>
                            <li><strong>Order Acceptance:</strong> All orders are subject to acceptance by our partner restaurants and confirmation from RailFeast. We reserve the right to decline an order for any reason, such as non-availability of items, restaurant operational issues, or train delays.</li>
                            <li><strong>Payment:</strong> Full payment must be made at the time of order placement through our available payment gateways. </li>
                        </ul>
                    </Section>

                    <Section title="2. Order Cancellation Policy">
                        <p>We understand that plans can change. Our cancellation policy is designed to be as fair as possible.</p>
                        <ul className="list-disc list-inside space-y-2 pl-4">
                            <li><strong>Cancellation Window:</strong> Orders can be canceled for a full refund up to 60 minutes before the train's scheduled arrival time at the designated delivery station.</li>
                            <li><strong>Late Cancellation:</strong> Cancellation requests made less than 60 minutes before the train's arrival time may not be eligible for a refund, as the restaurant may have already started preparing your meal.</li>
                            <li><strong>How to Cancel:</strong> Order cancellations can be initiated through the 'Track Order' or 'Order History' section of the application if the cancellation window is open.</li>
                        </ul>
                    </Section>

                    <Section title="3. Refund Policy">
                        <p>Refunds will be processed according to the following conditions:</p>
                        <ul className="list-disc list-inside space-y-2 pl-4">
                            <li><strong>Successful Cancellations:</strong> Full refunds will be issued for orders canceled within the specified cancellation window.</li>
                            <li><strong>Non-Delivery:</strong> If we fail to deliver your order due to a fault of our own or our restaurant partner, you will receive a full refund. We are not liable for non-delivery if the train is significantly delayed, rerouted, or if you are not present at your seat.</li>
                            <li><strong>Incorrect or Damaged Items:</strong> If you receive an incorrect item, a damaged meal, or are missing an item from your order, please contact our support team immediately. Upon verification, we will process a partial or full refund as appropriate.</li>
                            <li><strong>Refund Timeline:</strong> All refunds will be processed back to the original payment method within 5-7 business days.</li>
                        </ul>
                    </Section>
                    
                    <Section title="4. Complaint Acceptance Policy">
                        <p>We are committed to providing excellent service. If you are not satisfied, please let us know.</p>
                         <ul className="list-disc list-inside space-y-2 pl-4">
                            <li><strong>Lodging a Complaint:</strong> All complaints regarding food quality, delivery, or service must be raised within 12 hours of the delivery time.</li>
                            <li><strong>Required Information:</strong> To help us resolve your issue quickly, please provide your Order ID, a clear description of the issue, and photographic evidence if applicable (e.g., for incorrect or damaged items).</li>
                            <li><strong>Resolution:</strong> Our customer support team will review your complaint and work towards a fair resolution, which may include a refund, a credit for a future order, or other forms of compensation as deemed appropriate.</li>
                            <li><strong>Contact:</strong> Complaints can be sent to our support team at <a href="mailto:support@railfeast.example.com" className="text-primary-600 hover:underline">support@railfeast.example.com</a>.</li>
                        </ul>
                    </Section>
                    
                     <Section title="5. Changes to Terms">
                         <p>
                            We reserve the right, at our sole discretion, to modify or replace these Terms at any time. We will provide notice of any changes by posting the new Terms and Conditions on this page.
                        </p>
                    </Section>
                </article>
            </div>
        </div>
    );
};

export default TermsAndConditionsPage;