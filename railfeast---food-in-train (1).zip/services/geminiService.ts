import { GoogleGenAI } from "@google/genai";
import { MenuItem } from '../types';

// IMPORTANT: In a real application, the API key must be set in your environment variables.
// Do not hardcode the API key in the code.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // In a real app, you might have better error handling or fallback logic.
  // For this example, we'll just log a warning.
  console.warn("API_KEY environment variable not set. Gemini API calls will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const getMealRecommendations = async (restaurantName: string, station: string, menu: MenuItem[]): Promise<string> => {
    // If API key is not available, return a mock response.
    if (!API_KEY) {
        return Promise.resolve(`Since you're arriving at ${station}, you should try the best-seller from ${restaurantName}. How about starting with something light and then moving to a main course? Enjoy your meal!`);
    }

    const model = 'gemini-2.5-flash-preview-04-17';

    const menuString = menu.map(item => `${item.name} (${item.veg ? 'Jain' : ''}) - ${item.description}`).join('\n');

    const prompt = `
You are an expert food recommender for train passengers looking for pure vegetarian and Jain food. A user is looking for a meal from "${restaurantName}" to be delivered at "${station}" station. All food is strictly Jain (no onion, no garlic, no root vegetables).
Based on the restaurant and its Jain cuisine, provide a short, friendly, and enticing meal recommendation.
Keep it conversational and suggest 1 or 2 items from the menu. Do not list prices. Do not use markdown formatting.

Here is the Jain menu:
${menuString}

Example response:
"Since you're arriving at Surat, a city known for its delicious food, I'd suggest the Jain Pav Bhaji from Jainam Kitchen. It's a wonderful, flavorful dish without any root vegetables. For a complete meal, their Jain Thali is an excellent choice. Enjoy your sattvic meal on the rails!"

Now, provide a recommendation for a user ordering from "${restaurantName}" at "${station}".
`;

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                temperature: 0.8,
                topK: 40,
            }
        });

        // The response.text property directly gives the string output.
        const text = response.text;

        if (!text) {
          throw new Error("Received an empty response from the AI.");
        }
        
        return text.trim();

    } catch (error) {
        console.error("Error fetching Gemini recommendations:", error);
        // Fallback in case of API error
        return `We couldn't get an AI recommendation right now, but anything from ${restaurantName} at ${station} is sure to be delicious!`;
    }
};

export const generateRestaurantImage = async (prompt: string): Promise<string> => {
    if (!API_KEY) {
        const seed = prompt.replace(/\s+/g, '').slice(0, 10);
        console.warn("API_KEY not set. Falling back to placeholder image.");
        return `https://picsum.photos/seed/${seed}/400/300`;
    }

    try {
        const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt: prompt,
            config: { numberOfImages: 1, outputMimeType: 'image/jpeg' },
        });

        if (response.generatedImages && response.generatedImages.length > 0) {
            const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
            return `data:image/jpeg;base64,${base64ImageBytes}`;
        } else {
            throw new Error("No image was generated.");
        }
    } catch (error) {
        console.error("Error generating image with Gemini:", error);
        throw new Error("Failed to generate AI image. Please try again.");
    }
};
