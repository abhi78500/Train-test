import React from 'react';
import { OrderDetails } from '../../types';
import { ArrowLeftIcon, PrinterIcon } from '../IconComponents';

interface OrderBillPageProps {
    order: OrderDetails | null;
    onBack: () => void;
}

const OrderBillPage: React.FC<OrderBillPageProps> = ({ order, onBack }) => {

    const handlePrint = () => {
        window.print();
    };

    if (!order) {
        return (
            <div className="text-center p-12">
                <h2 className="text-xl font-bold">Order not found.</h2>
                <button onClick={onBack} className="mt-4 text-primary-600 hover:underline">Go Back</button>
            </div>
        );
    }
    
    const subtotal = order.cart.reduce((sum, cartItem) => sum + cartItem.item.price * cartItem.quantity, 0);
    const platformFee = order.totalAmount - subtotal;

    return (
        <div className="bg-slate-100 py-12">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="max-w-3xl mx-auto">
                    <div className="flex justify-between items-center mb-6 no-print">
                         <button onClick={onBack} className="flex items-center gap-2 text-slate-600 font-semibold hover:text-primary-600 transition-colors">
                            <ArrowLeftIcon className="w-5 h-5" />
                            Back to History
                        </button>
                        <button
                            onClick={handlePrint}
                            className="flex items-center gap-2 bg-primary-600 text-white font-bold py-2 px-4 rounded-md hover:bg-primary-700 transition-colors shadow-sm"
                        >
                            <PrinterIcon className="w-5 h-5" />
                            Print Bill
                        </button>
                    </div>

                    <div id="bill-to-print" className="bg-white p-8 sm:p-10 rounded-xl shadow-lg border">
                        <header className="flex justify-between items-start pb-6 border-b">
                            <div>
                                <h1 className="text-3xl font-bold text-primary-700">RailFeast</h1>
                                <p className="text-slate-500">Food Delivery in Train</p>
                            </div>
                            <div className="text-right">
                                <h2 className="text-2xl font-bold text-slate-800">Invoice</h2>
                                <p className="text-slate-500 font-mono">{order.id}</p>
                            </div>
                        </header>

                        <section className="grid grid-cols-2 sm:grid-cols-3 gap-6 my-6 text-sm">
                            <div>
                                <p className="text-slate-500 font-semibold">Billed To</p>
                                <p className="text-slate-800 font-medium">{order.name}</p>
                                <p className="text-slate-800 font-medium">{order.phone}</p>
                            </div>
                             <div>
                                <p className="text-slate-500 font-semibold">Delivered By</p>
                                <p className="text-slate-800 font-medium">{order.restaurantName}</p>
                                <p className="text-slate-800 font-medium">Coach: {order.coach}, Seat: {order.seat}</p>
                            </div>
                            <div className="sm:text-right">
                                <p className="text-slate-500 font-semibold">Date of Issue</p>
                                <p className="text-slate-800 font-medium">{new Date(order.date).toLocaleDateString()}</p>
                                <p className="text-slate-500 font-semibold mt-2">Payment</p>
                                <p className={`font-medium ${order.paymentStatus === 'Paid' ? 'text-green-600' : 'text-orange-600'}`}>
                                    {order.paymentMethod === 'COD' ? 'COD' : 'Online'} ({order.paymentStatus})
                                </p>
                            </div>
                        </section>

                        <section className="mt-8">
                            <table className="w-full text-left">
                                <thead className="bg-slate-50 text-slate-600 text-sm">
                                    <tr>
                                        <th className="p-3 font-semibold">Item</th>
                                        <th className="p-3 font-semibold text-center">Qty</th>
                                        <th className="p-3 font-semibold text-right">Price</th>
                                        <th className="p-3 font-semibold text-right">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {order.cart.map(cartItem => (
                                        <tr key={cartItem.item.id} className="border-b">
                                            <td className="p-3">{cartItem.item.name}</td>
                                            <td className="p-3 text-center">{cartItem.quantity}</td>
                                            <td className="p-3 text-right">₹{cartItem.item.price.toFixed(2)}</td>
                                            <td className="p-3 text-right font-medium">₹{(cartItem.item.price * cartItem.quantity).toFixed(2)}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </section>

                        <section className="flex justify-end mt-6">
                            <div className="w-full max-w-xs space-y-2 text-sm">
                                <div className="flex justify-between">
                                    <p className="text-slate-600">Subtotal</p>
                                    <p className="font-medium text-slate-800">₹{subtotal.toFixed(2)}</p>
                                </div>
                                <div className="flex justify-between">
                                    <p className="text-slate-600">Platform & Delivery Fee</p>
                                    <p className="font-medium text-slate-800">₹{platformFee.toFixed(2)}</p>
                                </div>
                                <div className="flex justify-between font-bold text-lg pt-2 border-t mt-2">
                                    <p>{order.paymentStatus === 'Paid' ? 'Grand Total (Paid)' : 'Amount Due'}</p>
                                    <p>₹{order.totalAmount.toFixed(2)}</p>
                                </div>
                            </div>
                        </section>

                        <footer className="mt-10 pt-6 border-t text-center text-slate-500 text-sm">
                            <p>Thank you for ordering with RailFeast!</p>
                            <p>We hope you enjoyed your meal.</p>
                        </footer>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default OrderBillPage;