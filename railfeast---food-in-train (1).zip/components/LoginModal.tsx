import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { XMarkIcon, TrainIcon } from './IconComponents';
import { MOCK_USERS } from '../constants';

interface LoginModalProps {
    isOpen: boolean;
    onClose: () => void;
    onLoginSuccess: (user: User) => void;
}

const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose, onLoginSuccess }) => {
    const [step, setStep] = useState<'details' | 'otp'>('details');
    const [mobile, setMobile] = useState('');
    const [email, setEmail] = useState('');
    const [otp, setOtp] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isSpecialUser, setIsSpecialUser] = useState(false);

    // Reset state when modal is closed/opened
    useEffect(() => {
        if (isOpen) {
            setStep('details');
            setMobile('');
            setEmail('');
            setOtp('');
            setError('');
            setIsLoading(false);
            setIsSpecialUser(false);
        }
    }, [isOpen]);

    const handleMobileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const newMobile = e.target.value;
        setMobile(newMobile);
        const specialUser = MOCK_USERS.find(u => u.mobile === newMobile && u.role !== 'customer');
        setIsSpecialUser(!!specialUser);
    }

    const handleSendOtp = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (!/^\d{10}$/.test(mobile)) {
            setError('Please enter a valid 10-digit mobile number.');
            return;
        }

        const user = MOCK_USERS.find(u => u.mobile === mobile);
        if (user && user.role !== 'customer') {
            // It's a special user, log them in directly
            onLoginSuccess(user);
            return;
        }

        if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            setError('Please enter a valid email address.');
            return;
        }
        
        setIsLoading(true);
        // Mock OTP sending
        setTimeout(() => {
            console.log(`Mock OTP for ${mobile}: 123456`);
            setIsLoading(false);
            setStep('otp');
        }, 1500);
    };

    const handleVerifyOtp = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (otp === '123456') {
            const existingUser = MOCK_USERS.find(u => u.mobile === mobile);
            if (existingUser) {
                 onLoginSuccess(existingUser);
            } else {
                 onLoginSuccess({ mobile, email, role: 'customer' });
            }
        } else {
            setError('Invalid OTP. Please try again.');
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm z-50 flex items-center justify-center p-4" role="dialog" aria-modal="true" aria-labelledby="login-title">
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm transform transition-all" onClick={(e) => e.stopPropagation()}>
                <div className="relative p-6 sm:p-8">
                    <button onClick={onClose} className="absolute top-4 right-4 p-1 rounded-full text-slate-400 hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-primary-500">
                        <span className="sr-only">Close login</span>
                        <XMarkIcon className="w-6 h-6" />
                    </button>
                    
                    <div className="flex flex-col items-center text-center">
                        <TrainIcon className="h-10 w-10 text-primary-600 mb-2"/>
                        <h2 id="login-title" className="text-2xl font-bold text-slate-800">
                            {step === 'details' ? 'Login or Sign Up' : 'Verify OTP'}
                        </h2>
                        <p className="mt-2 text-slate-600 text-sm">
                            {step === 'details' 
                                ? 'Enter your mobile number to get started.'
                                : `We've sent a 6-digit OTP to ${mobile}.`
                            }
                        </p>
                    </div>

                    {step === 'details' ? (
                        <form onSubmit={handleSendOtp} className="mt-6 space-y-4">
                            <div>
                                <label htmlFor="mobile" className="block text-sm font-medium text-slate-700">Mobile Number</label>
                                <input
                                    type="tel"
                                    id="mobile"
                                    value={mobile}
                                    onChange={handleMobileChange}
                                    placeholder="10-digit mobile number"
                                    maxLength={10}
                                    required
                                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                                />
                                {isSpecialUser && <p className="text-xs text-center mt-1 text-primary-600 font-semibold">Admin/Vendor/Agent login detected.</p>}
                            </div>
                             {!isSpecialUser && <div>
                                <label htmlFor="email" className="flex items-center justify-between text-sm font-medium text-slate-700">
                                    <span>Email ID</span>
                                    <span className="text-slate-400">Optional</span>
                                </label>
                                <input
                                    type="email"
                                    id="email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    placeholder="your.email@example.com"
                                    className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                                />
                            </div>}
                            {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                            <button type="submit" disabled={isLoading} className="w-full mt-4 bg-primary-600 text-white font-bold py-3 px-8 rounded-md hover:bg-primary-700 transition-colors duration-300 shadow-md disabled:bg-primary-400 disabled:cursor-not-allowed flex items-center justify-center">
                                {isLoading ? (
                                    <>
                                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                        </svg>
                                        Sending OTP...
                                    </>
                                ) : (isSpecialUser ? 'Login to Dashboard' : 'Send OTP')}
                            </button>
                        </form>
                    ) : (
                         <form onSubmit={handleVerifyOtp} className="mt-6 space-y-4">
                            <div>
                                <label htmlFor="otp" className="block text-sm font-medium text-slate-700">Enter OTP</label>
                                 <input
                                    type="text"
                                    id="otp"
                                    value={otp}
                                    onChange={(e) => setOtp(e.target.value)}
                                    placeholder="6-digit OTP"
                                    maxLength={6}
                                    required
                                    className="mt-1 block w-full px-3 py-2 text-center tracking-[0.5em] font-mono text-lg border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500"
                                />
                            </div>
                             {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                            <button type="submit" className="w-full mt-4 bg-primary-600 text-white font-bold py-3 px-8 rounded-md hover:bg-primary-700 transition-colors duration-300 shadow-md">
                                Verify & Proceed
                            </button>
                            <div className="text-center text-sm">
                                <button type="button" onClick={() => setStep('details')} className="font-medium text-primary-600 hover:text-primary-500">
                                    Change number
                                </button>
                            </div>
                        </form>
                    )}
                </div>
            </div>
        </div>
    );
};

export default LoginModal;