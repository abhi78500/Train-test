import React from 'react';
import { TrainRoute, StationInfo } from '../../types';
import { TrainIcon, CheckCircleIcon, XCircleIcon } from '../IconComponents';

interface StationsPageProps {
    route: TrainRoute;
    onSelectStation: (station: StationInfo) => void;
}

const StationsPage: React.FC<StationsPageProps> = ({ route, onSelectStation }) => {
    return (
        <div className="bg-slate-50 py-12 sm:py-16">
            <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-12">
                    <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900">Your Journey Route</h1>
                    <p className="mt-3 text-lg text-slate-600">
                        Showing upcoming stations for Train No. <span className="font-bold text-primary-700">{route.trainNo}</span>
                    </p>
                </div>
                
                <div className="max-w-2xl mx-auto">
                    <div className="flow-root">
                        <ul className="-mb-8">
                            {route.stations.map((station, stationIdx) => (
                                <li key={station.id}>
                                    <div className="relative pb-8">
                                        {stationIdx !== route.stations.length - 1 ? (
                                            <span className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-slate-300" aria-hidden="true" />
                                        ) : null}
                                        <div className="relative flex items-start space-x-4">
                                            <div>
                                                <div className="h-8 w-8 rounded-full bg-primary-500 flex items-center justify-center ring-8 ring-slate-50">
                                                    <TrainIcon className="h-5 w-5 text-white" />
                                                </div>
                                            </div>
                                            <div className="min-w-0 flex-1 pt-1.5">
                                                <div className="flex items-center justify-between">
                                                    <div>
                                                        <p className="text-lg font-semibold text-slate-800">{station.name} ({station.code})</p>
                                                        <p className="text-sm text-slate-500">ETA: {station.arrivalTime}</p>
                                                    </div>
                                                    {station.hasService ? (
                                                        <span className="inline-flex items-center gap-x-1.5 rounded-full bg-green-100 px-2 py-1 text-xs font-medium text-green-700">
                                                            <CheckCircleIcon className="h-4 w-4" />
                                                            Service Available
                                                        </span>
                                                    ) : (
                                                         <span className="inline-flex items-center gap-x-1.5 rounded-full bg-slate-100 px-2 py-1 text-xs font-medium text-slate-600">
                                                            <XCircleIcon className="h-4 w-4" />
                                                            Service Unavailable
                                                        </span>
                                                    )}
                                                </div>
                                                {station.hasService && (
                                                     <div className="mt-3">
                                                        <button 
                                                            onClick={() => onSelectStation(station)}
                                                            className="w-full sm:w-auto bg-primary-600 text-white font-bold py-2 px-6 rounded-md hover:bg-primary-700 transition-colors duration-300 shadow-sm"
                                                        >
                                                            View Restaurants
                                                        </button>
                                                     </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default StationsPage;